# Chinese Noether r10b release handoff

State: `MACHINE_VALIDATED_RELEASE_READY`; `publishable=true`.

- Root: `C:\Users\[USER]\Documents\interlanguage\03_projects\language_management\cjk\03_working_translations\zh_r10b`
- Scope: complete PRC-oriented Simplified-Chinese Emmy Noether cumulative reader; Hant, Singapore localization, TW/HK/MO localization, German editing, and SGA are outside this package.
- TeX: 1,874,083 B / 25,085 LF lines / `553446A494A59530946AB70EC2F672BED4D45A33B7FA554765A11B8C038DA6D4`.
- PDF: 3,129,044 B / 424 pages / `0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544`.
- Exact predecessor delta: control-comment lines 2 and 5 plus PDF-title line 25 only; 25,082 other lines, all substantive Chinese, and all mathematics remain exact.
- Machine validation: 32/32 source/lineage checks; three stable serial XeLaTeX passes with zero fatal/box/missing-character signals; deterministic six-font CMap injection; 34/34 ToUnicode; Poppler and pypdf C0/U+FFFD zero; raw/final 36-DPI pixels 424/424 equal; predecessor/current content, text, geometry, and fresh 120-DPI rasters 424/424 equal; all eight contact sheets and pages 1, 169, and 424 at original detail show no visual defect.

`verify.py` is the read-only package replay. `manifest.csv` lists every non-self member. External freeze receipts are under `C:\Users\[USER]\Documents\interlanguage\04_handoffs\zh_r10b`.

Human review, independent review, checker acceptance, clean-day counts, and self-acceptance prohibitions are not publication gates. Optional later review may add evidence but cannot block this package. No external/community/human certification is claimed. Publication has not yet been performed by this producer task.
