# Chinese Noether r10b durable state

Reconstruct from these exact files and receipts, never from a conversation summary.

- Scope: complete PRC-oriented zh-Hans Noether cumulative reader only. Hant, zh-Hans-SG, TW/HK/MO localization, German editing, and SGA are outside this bounded release.
- Immediate base: frozen r10 `base.tex`, 1,874,053 B / 25,085 lines / SHA-256 `14240969926ED46CCD1D9F75BA7EA8A25652B28FF27F436030F46D74DCFBA00E`; manifest `src/r10.csv`, 4,581 B / `F8647FE279273538F2E7702FB96CB633DDFA47CC59E856FBA6F272FC447EF371`, replay 54/54.
- Checker evidence: `src/chk.json`, return `ZHCHK-NOETHER-R10-RETURN-001`, 6,649 B / `4338E7695E92731F265CCDF523AD0A2B309EC7047922164072318C544E4E1323`.
- Exact TeX control delta: lines 2 and 5 supersede obsolete review gates; line 25 changes only the PDF title from r9 to r10. All 25,082 other lines, all substantive Chinese, and all mathematics are unchanged.
- Operative translation authority: v047/ED0011. Preserved freeze-time v051 remains candidate-only and causes no target action. German was not mutated.
- Output TeX: `reader.tex`; current identity is pinned by `return.json`, `manifest.csv`, and external freeze receipts.
- Output PDF: `reader.pdf`, 424 pages; `/Title` is `Noether Simplified Chinese cumulative rebase r10`, `/Author` is `Emmy Noether`.
- Machine gates: exact source reconstruction; three stable serial XeLaTeX passes; zero fatal/box/missing-character signals; deterministic six-font CMap repair; 34/34 ToUnicode; Poppler and pypdf C0/U+FFFD zero; raw/final 36-DPI equality 424/424; r10/r10b content/text/geometry/fresh 120-DPI equality 424/424; all-page contact-sheet inspection plus original-detail spot checks.
- State: `MACHINE_VALIDATED_RELEASE_READY`; publishable. Human review, independent review, checker acceptance, clean-day counts, and self-acceptance rules are not publication prerequisites. Later audit is optional additive evidence and does not constitute a gate.
- Claim boundary: this package is not claimed to have external, community, or human certification. Publication has not yet been performed by this producer task.
- Cursor: seal the exact current root, replay its verifier twice externally, append the release decision, and expose the machine-validated package for publication. Preserve historical receipts unchanged as evidence, not current release authority.
