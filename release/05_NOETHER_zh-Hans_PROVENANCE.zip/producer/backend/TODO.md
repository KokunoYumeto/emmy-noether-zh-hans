# Complete ordered to-do list

- [x] Create the corrected 3,943-character Codex durable goal from the exact transcript plus later raw messages.
- [x] Create this sidecar-owned shallow root and reconstruction files.
- [x] Rehash and log all initial controls; append decision `CJK-NOT-D002`.
- [x] Discover relevant active/recent CJK tasks using the app's task registry.
- [x] For each relevant CJK translation task, check `sent.jsonl`, send exact `msg.txt` once, and append the receipt. Global coverage records are `CJK-NOT-S001` through `CJK-NOT-S005`; never resend.
- [x] Inventory task IDs, titles, lanes, ownership, and active state; durable roots remain to be bound during artifact audit.
- [x] Read the controlling governance, methodology, CJK field policy, and publication method completely; record exact hashes.
- [x] Audit Chinese artifacts read-only for notation, morphology, traps, scripts, and validation methods.
- [x] Audit Japanese artifacts read-only for the same categories.
- [x] Audit Korean artifacts read-only for the same categories.
- [x] Audit combined-CJK/CJKV crosswalks and adverse evidence without treating them as certification.
- [x] Log all subagent assignments/results and independently verify every integrated claim.
- [x] Research current primary/official Chinese mathematical/style/encoding sources.
- [x] Research current primary/official Japanese mathematical/style/encoding sources.
- [x] Research current primary/official Korean mathematical/style/encoding sources.
- [x] Build `sources.tsv`, typed `evidence.jsonl`, and `adverse.tsv` with stable IDs and hashes/URLs.
- [x] Separate shared structural/serialization invariants from language-local typography, morphology, terminology, and prose.
- [x] Record sense windows, excluded senses, lexical-attractor basins, and qualitative Mandarin-Simplified dominance debt.
- [x] Draft `STANDARD.md` with MUST/SHOULD/MAY rules, algorithms, fail-closed checks, examples, counterexamples, and adoption guidance.
- [x] Create/validate a JSON Schema and machine-readable crosswalk without invalidating existing CJK schemas.
- [x] Identify and publicly replay the existing Interlanguage methodology sidecar: concept DOI `10.5281/zenodo.21124403`, current record `21810835`, 100 files.
- [x] Prepare compact public files, rights, relations, citation metadata, manifest, and verifier.
- [x] Run schema, hash, claim-link, example, privacy, credential, local-path, rights, and relation checks.
- [x] Run the final verifier twice and require byte-identical receipts.
- [x] Create same-concept draft `21940307` and prove its initial 100 filenames/sizes/checksums exactly match current record `21810835`.
- [x] Retain 99 top-level files exactly and replace only the old transport container with a successor that nests the old container byte-for-byte plus the CJK package and an exact index.
- [x] Superseded by direct user instruction and `CJK-NOT-D017`: publish dedicated concept `21939357` as well as retaining the Interlanguage parent; v1.0.1 record `21939358` is public and exactly replayed.
- [x] Verify any GitHub supplement used plus anonymous Zenodo/API/DOI readbacks; record exact identities and base-file preservation.
- [x] Append final decision and lessons records; cite latest decision ID in handoff.
- [x] Archive only obsolete sidecar scratch to the required `old stuff` directory, verify the ZIP, and remove exact loose duplicates.
- [x] Mark the goal complete only after every preceding item is satisfied.

## Phase 2 — standards comparison and successor (250,000-token limit removed by user)

- [x] Create and externalize goal `CJK-NOT-20260815-R2` in `GOAL2.md`.
- [x] Pin dedicated v1.0.1 and parent DOI identities in `receipts/doi.json`.
- [x] Send the publication notice once to nine relevant tasks with purpose-level deduplication.
- [x] Schedule the one-shot four-hour adoption check for 2026-08-15 18:10 Europe/Berlin.
- [x] Survey primary MathML/OpenMath/OMDoc and TeX/LaTeX interchange standards.
- [x] Survey primary Unicode math, normalization, East Asian width/line-breaking, CLReq, JLReq, and KLReq standards.
- [x] Survey primary PDF/UA, tagged-PDF, ToUnicode, font-embedding, extraction, and accessibility standards.
- [x] Survey independent Chinese, Japanese, Korean, and useful Vietnamese terminology/style authorities without cross-language authorization.
- [x] Record all sources, exact versions, URLs, access dates, evidence classes, and adverse evidence durably.
- [x] Build the requirement-level v1.0.1 crosswalk with corroborated/narrower/broader/conflicting/absent/missing-local classifications.
- [x] Extract positive implementation to-dos and specify fixtures for verified gaps.
- [x] Decide through append-only evidence whether a normative successor or a no-change research report is warranted.
- [x] Build and verify any successor in a short owned root; preserve v1.0.1 bytes.
- [x] Publish only under dedicated concept `10.5281/zenodo.21939357`, retaining the additive Interlanguage parent relation. Version `10.5281/zenodo.21949644` is public and all 45 files replay exactly; see `receipts/v110.public.json` and `CJK-NOT-D034`.
- [x] Record the 18:10 adoption result and verified implementation DOI links, if any. Result: 0 verified adopters, no implementation DOI links, 9/9 deduplicated reminders sent; see `receipts/adoption-check.json` and `CJK-NOT-D032`.
- [x] Complete the active unbounded goal only after cited survey, crosswalk, tested result, public receipts, and durable lessons are exact. Completed by `CJK-NOT-D034` after anonymous DOI/API and 45-file byte/MD5/SHA-256 replay.

## Phase 3 — attribution correction and immutable artifact successor

- [x] Reopen the completed publication from direct user corrections that the author and contributor data were wrong.
- [x] Independently verify the authoritative parent attribution: author `OpenAI Codex`; contributor `AI typesetting & translation`, type `Other`; no affiliations.
- [x] Correct published v1.1.0 record `21949644` metadata in place without changing its DOI, lineage, or 45 public files.
- [x] Verify corrected v1.1.0 metadata in both Zenodo and DataCite and replay its unchanged file census.
- [x] Preserve frozen v1.1.0 artifacts as adverse history; do not rewrite immutable embedded files.
- [x] Reserve same-concept v1.1.1 record `21969542` and build an attribution-only successor.
- [x] Preserve 29 loose files byte-exact, change exactly 15 loose metadata/control files, rebuild the deterministic archive, and verify 31/31 twice.
- [x] Replace the exact draft file set, save the metadata, and authenticated-replay all 45 names, sizes, and MD5 identities before publication.
- [x] Publish v1.1.1 exactly once under DOI `10.5281/zenodo.21969542`.
- [x] Anonymously download and replay all 45 public files by size, MD5, and SHA-256; verify Zenodo, DataCite, version DOI, and concept DOI.
- [x] Append decision `CJK-NOT-D035`, preserve every earlier receipt, and close with no Git or translation-lane mutation.
- [x] Delete automation `cjk-backend-adoption-check` so it can never create another task.
- [x] Fully read task `01a0069e-0891-7112-9686-22eca93c5624`, absorb its material results into `receipts/adopt-task.json`, and archive it.

## Phase 4 — immediate cleanup gate

- [x] Audit only exact task-owned staging and duplicate release paths; use no Git or broad filesystem scan.
- [x] Archive nine disposable targets into one no-overwrite ZIP under `old stuff`, with a 95-file SHA-256 index.
- [x] Independently replay all 96 ZIP members and all 95 loose source identities before deletion.
- [x] Delete only the nine exact archived originals and preserve canonical releases, evidence, receipts, ledgers, and reproducibility scripts.
- [x] Record the exact archive, deletion, and retained-live census in `receipts/cleanup2.json`.

## Phase 5 — first verified implementation registry release

- [x] Independently rehash the accepted Chinese R10b checker and publication receipts and prove the exact public implementation DOI.
- [x] Bound `CJK-IMPL-001` to seven backend-v1.0.1 mechanical states; do not claim full report-v3 conformance.
- [x] Reserve same-concept v1.1.2 record `22167949` and preserve published v1.1.1 immutably.
- [x] Build a registry-only successor with exactly 15 changed and 29 byte-identical loose files.
- [x] Regenerate the 43-row manifest and 44-member deterministic archive; replay 32/32 twice with byte-identical output.
- [x] Independently audit the local package, evidence crosswalk, schemas, manifest, archive, and v1.1.1 preservation.
- [x] Replace only the 15 changed draft files and old archive, preserve 29 inherited files, and authenticated-replay the exact 45-file draft twice.
- [x] Publish v1.1.2 under DOI `10.5281/zenodo.22167949` and link Chinese DOI `10.5281/zenodo.22167842` as `IsReferencedBy`.
- [x] Anonymously replay all 45 public files, manifest, archive, Zenodo metadata, DataCite relations, both backend DOI routes, and the unchanged Chinese implementation DOI.
- [x] Append decision `CJK-NOT-D038`, update durable state, and close without Git or translation-lane mutation.
- [x] Consume and independently rehash checker acceptance `ZHCHK-NOETHER-CJK-V112-001`; append `CJK-NOT-D039` and close with `PASS_NO_BLOCKERS`.

## Phase 6 — Chinese v1.0.2 provenance-successor registry update

- [x] Rehash and read Zenodo publication return `ZHCHK-NOETHER-ZH-PUB-RETURN-003`; verify public v1.0.2 identity, six-file census, manifest, provenance ZIP, and concept/latest DOI routing.
- [x] Rehash and read GitHub publication return `ZHCHK-NOETHER-GITHUB-V102-001`; verify public main/tag identities and direct manifest/provenance downloads.
- [x] Decide the bounded treatment: retain admitted implementation DOI `10.5281/zenodo.22167842`; add `10.5281/zenodo.22172487` only as a verified provenance/preservation successor; preserve all seven states and the no-full-report-v3 boundary.
- [x] Prove that public backend v1.1.2 remains truthful, current, immutable, and requires no correction.
- [x] Consume and independently replay `ZHCHK-NOETHER-ZH-META-001`: Zenodo and DataCite expose `IsDerivedFrom` to source DOI `10.5281/zenodo.21848304`, whose public `20-de.tex` is 2,153,594 B / `9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3`; treat it as provenance-only.
- [ ] Obtain authenticated Zenodo write access with record-management scope and reserve the next version under concept `10.5281/zenodo.21939357`; no draft currently exists.
- [ ] Build `v113` as a short, shallow registry-only successor; preserve the 29 normative/functional files byte-identical and change only the versioned registry/metadata/control set.
- [ ] Run the pinned verifier twice, require byte-identical output, independently audit the manifest/archive/delta, and freeze exact receipts.
- [ ] Upload only the exact changed files plus successor archive, preserve inherited files, replay the authenticated draft twice, publish once, and anonymously replay every public byte and DOI/DataCite relation.
- [ ] Append the final decision and checker handoff only after the static v1.1.3 DOI exists; do not touch any language lane.
