# Simplified-Chinese Noether cumulative provenance bundle

This v1.0.3 bundle cumulatively preserves the Chinese translation decision log, independent-checker decisions and state through ZHCHK-D132 / STATE-20260830-044, producer backend consumption through CJK-NOT-D041, the accepted R10b freeze and return, publication evidence through v1.0.2, the exact static German-source relation, and the public repository metadata available before the v1.0.3 transaction.

It excludes corpus duplication, page-render dumps, caches, credentials, and disposable scratch. Textual copies redact the local account holder's first name and email addresses. MANIFEST.csv binds every local source preimage to its public transformed bytes and excludes itself.

The reader, source ZIP, evidence ZIP, and exact R10b body are inherited byte-for-byte. This is audit evidence, not a new translation, authority change, regional localization, or expanded backend-conformance claim.
