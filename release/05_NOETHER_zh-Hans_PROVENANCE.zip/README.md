# Simplified-Chinese Noether provenance bundle

This additive bundle preserves the complete Chinese producer decision log, the complete independent-checker decision/event state, the accepted R10b return, freeze and verifier controls, and the v1.0.1 publication/backend receipts available before the v1.0.2 transaction.

It intentionally excludes corpus duplication, rendered-page dumps, build caches, credentials, and disposable scratch. Textual copies redact the local account holder's first name and email addresses. MANIFEST.csv records every local source preimage hash and every public transformed hash, so the privacy transformation is explicit and auditable. MANIFEST.csv excludes itself.

The front-facing corpus reader remains the existing complete reader. This bundle is audit evidence, not a new translation, regional localization, or claim of full CJK backend report-v3 conformance.
