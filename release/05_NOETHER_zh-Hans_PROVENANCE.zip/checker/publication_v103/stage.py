from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
RESERVATION = json.loads((HERE / "reserve.json").read_text(encoding="utf-8"))
DRAFT_ID = int(RESERVATION["draft_id"])
BUCKET = str(RESERVATION["bucket"]).rstrip("/")
REPLACE = {
    "03_NOETHER_zh-Hans_SHA256.txt",
    "05_NOETHER_zh-Hans_PROVENANCE.zip",
}
TOKEN = TOKEN_PATH.read_text(encoding="utf-8").strip()
if len(TOKEN) < 40 or any(ch.isspace() for ch in TOKEN):
    raise SystemExit("credential file did not contain one plausible token")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def request(
    url: str,
    method: str = "GET",
    data: bytes | None = None,
    content_type: str = "application/json",
) -> tuple[int, bytes]:
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": content_type,
            "User-Agent": "zh-noether-v103-provenance/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=240) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Zenodo HTTP {exc.code}: {body}") from None


def draft() -> dict:
    _, body = request(f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}")
    return json.loads(body)


def main() -> int:
    if (HERE / "stage.json").exists():
        raise SystemExit("stage.json already exists; refusing a second stage transaction")
    current = draft()
    inherited_names = {item.get("filename") for item in current.get("files", [])}
    expected_inherited = {
        "00_NOETHER_zh-Hans_COMPLETE_READER.pdf",
        "01_NOETHER_zh-Hans_SOURCE.zip",
        "02_NOETHER_zh-Hans_EVIDENCE.zip",
        "03_NOETHER_zh-Hans_SHA256.txt",
        "04_NOETHER_zh-Hans_R10B_BODY.pdf",
        "05_NOETHER_zh-Hans_PROVENANCE.zip",
    }
    if inherited_names != expected_inherited:
        raise SystemExit(f"unexpected inherited file set: {sorted(inherited_names)}")
    deleted: list[str] = []
    for item in current.get("files", []):
        if item.get("filename") in REPLACE:
            status, _ = request(
                f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}/files/{item['id']}",
                method="DELETE",
            )
            if status not in (200, 202, 204):
                raise SystemExit(f"unexpected delete status {status}")
            deleted.append(str(item["filename"]))
    if set(deleted) != REPLACE:
        raise SystemExit(f"replacement delete set mismatch: {deleted}")

    uploads: list[dict[str, object]] = []
    for name in ("05_NOETHER_zh-Hans_PROVENANCE.zip", "03_NOETHER_zh-Hans_SHA256.txt"):
        data = (HERE / name).read_bytes()
        url = BUCKET + "/" + urllib.parse.quote(name, safe="")
        status, body = request(url, method="PUT", data=data, content_type="application/octet-stream")
        if status not in (200, 201):
            raise SystemExit(f"unexpected upload status {status} for {name}")
        uploads.append(
            {
                "name": name,
                "bytes": len(data),
                "sha256": sha256(data),
                "response_sha256": sha256(body),
            }
        )

    current = draft()
    metadata = dict(current["metadata"])
    metadata["version"] = "1.0.3"
    metadata["publication_date"] = "2026-08-30"
    description = str(metadata.get("description", ""))
    description = description.replace(
        "https://zenodo.org/records/22172487/files/00_NOETHER_zh-Hans_COMPLETE_READER.pdf",
        f"https://zenodo.org/records/{DRAFT_ID}/files/00_NOETHER_zh-Hans_COMPLETE_READER.pdf",
    )
    provenance_sha = sha256((HERE / "05_NOETHER_zh-Hans_PROVENANCE.zip").read_bytes())
    note = (
        "<p><strong>Version 1.0.3 cumulative provenance successor (2026-08-30):</strong> "
        "refreshes <code>05_NOETHER_zh-Hans_PROVENANCE.zip</code> (SHA-256 "
        f"<code>{provenance_sha}</code>) with the complete Chinese translation decision "
        "log, independent-checker decisions through <code>ZHCHK-D132</code>, event state "
        "through <code>STATE-20260830-044</code>, producer source-relation consumption "
        "through <code>CJK-NOT-D041</code>, v1.0.2 publication/GitHub/source-relation "
        "evidence, and exact source-preimage/public-transform hashes. The reader, source "
        "ZIP, evidence ZIP, and exact R10b body are inherited byte-for-byte. No Chinese "
        "wording, mathematics, authority binding, backend-conformance scope, or regional-"
        "localization claim changed.</p>"
    )
    if "Version 1.0.3 cumulative provenance successor" not in description:
        description += note
    if "TTP" in description or "Translation and Transcription Project" in description:
        raise SystemExit("forbidden project label in description")
    if "[USER]" in description:
        raise SystemExit("private name in description")
    metadata["description"] = description
    status, body = request(
        f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}",
        method="PUT",
        data=json.dumps({"metadata": metadata}, ensure_ascii=False).encode("utf-8"),
    )
    if status != 200:
        raise SystemExit(f"unexpected metadata status {status}")

    result = {
        "schema": "zh-noether-v103-stage-v1",
        "result": "PASS",
        "draft_id": DRAFT_ID,
        "reserved_doi": RESERVATION["reserved_doi"],
        "deleted": sorted(deleted),
        "uploads": uploads,
        "metadata_status": status,
        "metadata_response_sha256": sha256(body),
        "credential_material_logged": False,
    }
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    (HERE / "stage.json").write_text(encoded, encoding="utf-8", newline="\n")
    print(
        json.dumps(
            {
                "result": "PASS",
                "draft_id": DRAFT_ID,
                "deleted": len(deleted),
                "uploads": len(uploads),
                "receipt_bytes": len(encoded.encode("utf-8")),
                "receipt_sha256": sha256(encoded.encode("utf-8")),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
