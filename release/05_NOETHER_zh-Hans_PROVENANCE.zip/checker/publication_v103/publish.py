from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
RESERVATION = json.loads((HERE / "reserve.json").read_text(encoding="utf-8"))
DRAFT_ID = int(RESERVATION["draft_id"])


def main() -> int:
    if (HERE / "publish.json").exists():
        raise SystemExit("publish.json already exists; refusing a second publish transaction")
    first = (HERE / "v1.json").read_bytes()
    second = (HERE / "v2.json").read_bytes()
    if first != second:
        raise SystemExit("draft verifier outputs are not byte-identical")
    verified = json.loads(first)
    if verified.get("result") != "PASS" or verified.get("errors") != []:
        raise SystemExit("draft verifier did not pass")
    token = TOKEN_PATH.read_text(encoding="utf-8").strip()
    if len(token) < 40 or any(ch.isspace() for ch in token):
        raise SystemExit("credential file did not contain one plausible token")
    req = urllib.request.Request(
        f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}/actions/publish",
        data=b"{}",
        method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "zh-noether-v103-provenance/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=240) as response:
            status = response.status
            body = response.read()
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Zenodo HTTP {exc.code}: {error_body}") from None
    if status not in (200, 201, 202):
        raise SystemExit(f"unexpected publish status {status}")
    published = json.loads(body)
    result = {
        "schema": "zh-noether-v103-publish-v1",
        "result": "PASS",
        "http": status,
        "record_id": published.get("record_id") or published.get("id"),
        "doi": published.get("doi") or published.get("metadata", {}).get("doi"),
        "conceptrecid": published.get("conceptrecid"),
        "state": published.get("state"),
        "submitted": published.get("submitted"),
        "response_sha256": hashlib.sha256(body).hexdigest().upper(),
        "credential_material_logged": False,
    }
    if result["doi"] != RESERVATION["reserved_doi"]:
        raise SystemExit("published DOI differs from reservation")
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    (HERE / "publish.json").write_text(encoded, encoding="utf-8", newline="\n")
    print(
        json.dumps(
            {
                "result": "PASS",
                "http": status,
                "record_id": result["record_id"],
                "doi": result["doi"],
                "receipt_bytes": len(encoded.encode("utf-8")),
                "receipt_sha256": hashlib.sha256(encoded.encode("utf-8")).hexdigest().upper(),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
