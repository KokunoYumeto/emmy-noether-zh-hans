from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import requests


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
RESERVATION = json.loads((HERE / "reserve.json").read_text(encoding="utf-8"))
DRAFT_ID = int(RESERVATION["draft_id"])
TITLE = "埃米·诺特数学著作全集——完整简体中文版 / Emmy Noether: Complete Simplified Chinese Corpus Edition"
EXPECTED_RELATIONS = [
    ("isPartOf", "10.5281/zenodo.20412587", "dataset"),
    ("isDerivedFrom", "10.5281/zenodo.21848304", "dataset"),
    ("isSupplementedBy", "https://github.com/KokunoYumeto/emmy-noether-zh-hans", "software"),
]
BASE_EXPECTED = {
    "00_NOETHER_zh-Hans_COMPLETE_READER.pdf": (3169126, "0B6D9B78874325DE2C82C15FB07C6FE61DDB1A428E5F995A2F75D40961AA9079"),
    "01_NOETHER_zh-Hans_SOURCE.zip": (69998588, "D790F65B07E632D7E239C429444C1458523EAAF19CB81FEF8D9245351E8B1550"),
    "02_NOETHER_zh-Hans_EVIDENCE.zip": (1648561, "FE5B200E57C583710715D492072BEEC0504009732B6A3EEE2C3459CE90E22B9C"),
    "04_NOETHER_zh-Hans_R10B_BODY.pdf": (3129044, "0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544"),
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    token = TOKEN_PATH.read_text(encoding="utf-8").strip()
    if len(token) < 40 or any(ch.isspace() for ch in token):
        raise SystemExit("credential file did not contain one plausible token")
    expected = dict(BASE_EXPECTED)
    for name in ("03_NOETHER_zh-Hans_SHA256.txt", "05_NOETHER_zh-Hans_PROVENANCE.zip"):
        path = HERE / name
        expected[name] = (path.stat().st_size, sha256_file(path))

    session = requests.Session()
    session.headers.update(
        {"Authorization": f"Bearer {token}", "User-Agent": "zh-noether-v103-draft-verify/1.0"}
    )
    draft_response = session.get(
        f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}", timeout=120
    )
    draft_response.raise_for_status()
    draft = draft_response.json()
    files = {item["filename"]: item for item in draft.get("files", [])}
    errors: list[str] = []
    if set(files) != set(expected):
        errors.append(
            "set:"
            + json.dumps(
                {"missing": sorted(set(expected) - set(files)), "extra": sorted(set(files) - set(expected))},
                sort_keys=True,
                separators=(",", ":"),
            )
        )
    identities: list[dict[str, object]] = []
    for name in sorted(expected):
        item = files.get(name)
        if item is None:
            continue
        response = session.get(item["links"]["download"], stream=True, timeout=300)
        response.raise_for_status()
        digest = hashlib.sha256()
        size = 0
        for chunk in response.iter_content(1024 * 1024):
            if chunk:
                size += len(chunk)
                digest.update(chunk)
        actual_sha = digest.hexdigest().upper()
        expected_bytes, expected_sha = expected[name]
        if size != expected_bytes:
            errors.append(f"bytes:{name}")
        if actual_sha != expected_sha:
            errors.append(f"sha256:{name}")
        identities.append({"name": name, "bytes": size, "sha256": actual_sha})

    metadata = draft.get("metadata", {})
    if metadata.get("version") != "1.0.3":
        errors.append("metadata:version")
    if metadata.get("publication_date") != "2026-08-30":
        errors.append("metadata:publication_date")
    if metadata.get("title") != TITLE:
        errors.append("metadata:title")
    if metadata.get("access_right") != "open":
        errors.append("metadata:access")
    description = str(metadata.get("description", ""))
    for value, label in (
        ("Version 1.0.3 cumulative provenance successor", "v103_note"),
        ("10.5281/zenodo.21848304", "source_doi"),
        ("20-de.tex", "source_file"),
        ("NOETH-DE-AUTH-v047-20260808 / ED0011", "source_authority"),
        ("9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3", "source_hash"),
    ):
        if value not in description:
            errors.append(f"metadata:{label}")
    if "TTP" in description or "Translation and Transcription Project" in description:
        errors.append("metadata:forbidden_project_label")
    if "[USER]" in description:
        errors.append("metadata:private_name")
    relations = [
        (item.get("relation"), item.get("identifier"), item.get("resource_type"))
        for item in metadata.get("related_identifiers", [])
    ]
    if relations != EXPECTED_RELATIONS:
        errors.append("metadata:relations")
    reserved = metadata.get("prereserve_doi", {})
    if reserved.get("doi") != RESERVATION["reserved_doi"]:
        errors.append("metadata:reserved_doi")

    manifest = (HERE / "03_NOETHER_zh-Hans_SHA256.txt").read_text(encoding="utf-8")
    if f"exact_version_doi\t{RESERVATION['reserved_doi']}\n" not in manifest:
        errors.append("manifest:doi")
    if "version\t1.0.3\n" not in manifest:
        errors.append("manifest:version")
    for name, (size, digest) in expected.items():
        if name == "03_NOETHER_zh-Hans_SHA256.txt":
            continue
        if f"{name}\t{size}\t{digest}\n" not in manifest:
            errors.append(f"manifest:row:{name}")

    inventory = json.dumps(identities, sort_keys=True, separators=(",", ":")).encode("utf-8")
    result = {
        "schema": "zh-noether-v103-draft-verify-v1",
        "result": "PASS" if not errors else "FAIL",
        "draft_id": DRAFT_ID,
        "reserved_doi": RESERVATION["reserved_doi"],
        "files": len(files),
        "bytes": sum(item[0] for item in expected.values()),
        "inventory_sha256": hashlib.sha256(inventory).hexdigest().upper(),
        "relations": [list(item) for item in relations],
        "credential_material_logged": False,
        "errors": errors,
    }
    encoded = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    if args.output:
        target = args.output if args.output.is_absolute() else HERE / args.output
        target.write_text(encoded, encoding="utf-8", newline="\n")
    print(encoded, end="")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
