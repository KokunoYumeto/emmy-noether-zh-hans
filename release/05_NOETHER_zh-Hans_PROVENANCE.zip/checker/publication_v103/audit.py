from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import time
import zipfile
from pathlib import Path

import requests


HERE = Path(__file__).resolve().parent
PUBLICATION = json.loads((HERE / "publish.json").read_text(encoding="utf-8"))
RECORD_ID = int(PUBLICATION["record_id"])
VERSION_DOI = str(PUBLICATION["doi"])
CONCEPT_DOI = "10.5281/zenodo.21933034"
TITLE = "埃米·诺特数学著作全集——完整简体中文版 / Emmy Noether: Complete Simplified Chinese Corpus Edition"
BASE_EXPECTED = {
    "00_NOETHER_zh-Hans_COMPLETE_READER.pdf": (3169126, "0B6D9B78874325DE2C82C15FB07C6FE61DDB1A428E5F995A2F75D40961AA9079"),
    "01_NOETHER_zh-Hans_SOURCE.zip": (69998588, "D790F65B07E632D7E239C429444C1458523EAAF19CB81FEF8D9245351E8B1550"),
    "02_NOETHER_zh-Hans_EVIDENCE.zip": (1648561, "FE5B200E57C583710715D492072BEEC0504009732B6A3EEE2C3459CE90E22B9C"),
    "04_NOETHER_zh-Hans_R10B_BODY.pdf": (3129044, "0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544"),
}
EXPECTED_RELATIONS = [
    ("isPartOf", "10.5281/zenodo.20412587", "dataset"),
    ("isDerivedFrom", "10.5281/zenodo.21848304", "dataset"),
    ("isSupplementedBy", "https://github.com/KokunoYumeto/emmy-noether-zh-hans", "software"),
]
TEXT_SUFFIXES = {".cff", ".csv", ".json", ".jsonl", ".md", ".py", ".tsv", ".txt"}
PRIVATE_NAME_RE = re.compile(r"(?i)[USER]")
EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
SECRET_PATTERNS = {
    "github_classic": re.compile(rb"ghp_[A-Za-z0-9]{20,}"),
    "github_fine_grained": re.compile(rb"github_pat_[A-Za-z0-9_]{20,}"),
    "jwt": re.compile(rb"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
    "assigned_secret": re.compile(
        rb"(?i)(?:access[_-]?token|api[_-]?key|password|secret)\s*[:=]\s*[\"']?[A-Za-z0-9_./+-]{16,}"
    ),
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    expected = dict(BASE_EXPECTED)
    for name in ("03_NOETHER_zh-Hans_SHA256.txt", "05_NOETHER_zh-Hans_PROVENANCE.zip"):
        path = HERE / name
        expected[name] = (path.stat().st_size, sha256_file(path))

    errors: list[str] = []
    session = requests.Session()
    session.headers.update({"User-Agent": "zh-noether-v103-public-audit/1.0"})
    record_response = session.get(f"https://zenodo.org/api/records/{RECORD_ID}", timeout=120)
    record_response.raise_for_status()
    record = record_response.json()
    metadata = record.get("metadata", {})
    files = {item["key"]: item for item in record.get("files", [])}
    if set(files) != set(expected):
        errors.append(
            "set:"
            + json.dumps(
                {"missing": sorted(set(expected) - set(files)), "extra": sorted(set(files) - set(expected))},
                sort_keys=True,
                separators=(",", ":"),
            )
        )

    identities: list[dict[str, object]] = []
    captured: dict[str, bytes] = {}
    for name in sorted(expected):
        item = files.get(name)
        if item is None:
            continue
        response = session.get(item["links"]["self"], stream=True, timeout=300)
        response.raise_for_status()
        sha = hashlib.sha256()
        md5 = hashlib.md5()
        size = 0
        collect = name in {"03_NOETHER_zh-Hans_SHA256.txt", "05_NOETHER_zh-Hans_PROVENANCE.zip"}
        buffer = bytearray()
        for chunk in response.iter_content(1024 * 1024):
            if not chunk:
                continue
            size += len(chunk)
            sha.update(chunk)
            md5.update(chunk)
            if collect:
                buffer.extend(chunk)
        actual_sha = sha.hexdigest().upper()
        actual_md5 = md5.hexdigest().upper()
        expected_bytes, expected_sha = expected[name]
        api_md5 = str(item.get("checksum", "")).removeprefix("md5:").upper()
        if size != expected_bytes:
            errors.append(f"bytes:{name}")
        if actual_sha != expected_sha:
            errors.append(f"sha256:{name}")
        if actual_md5 != api_md5:
            errors.append(f"md5:{name}")
        identities.append({"name": name, "bytes": size, "md5": actual_md5, "sha256": actual_sha})
        if collect:
            captured[name] = bytes(buffer)

    if record.get("doi") != VERSION_DOI:
        errors.append("metadata:doi")
    if record.get("conceptdoi") != CONCEPT_DOI:
        errors.append("metadata:concept_doi")
    if metadata.get("version") != "1.0.3":
        errors.append("metadata:version")
    if metadata.get("title") != TITLE:
        errors.append("metadata:title")
    if metadata.get("access_right") != "open":
        errors.append("metadata:access")
    description = str(metadata.get("description", ""))
    for value, label in (
        ("Version 1.0.3 cumulative provenance successor", "v103_note"),
        ("10.5281/zenodo.21848304", "source_doi"),
        ("20-de.tex", "source_file"),
        ("NOETH-DE-AUTH-v047-20260808 / ED0011", "source_authority"),
        ("9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3", "source_hash"),
    ):
        if value not in description:
            errors.append(f"metadata:{label}")
    if "TTP" in description or "Translation and Transcription Project" in description:
        errors.append("metadata:forbidden_project_label")
    if PRIVATE_NAME_RE.search(description):
        errors.append("metadata:private_name")
    relations = [
        (item.get("relation"), item.get("identifier"), item.get("resource_type"))
        for item in metadata.get("related_identifiers", [])
    ]
    if relations != EXPECTED_RELATIONS:
        errors.append("metadata:relations")

    public_manifest = captured.get("03_NOETHER_zh-Hans_SHA256.txt", b"").decode("utf-8")
    if f"exact_version_doi\t{VERSION_DOI}\n" not in public_manifest:
        errors.append("manifest:doi")
    if "version\t1.0.3\n" not in public_manifest:
        errors.append("manifest:version")
    for name, (size, digest) in expected.items():
        if name == "03_NOETHER_zh-Hans_SHA256.txt":
            continue
        if f"{name}\t{size}\t{digest}\n" not in public_manifest:
            errors.append(f"manifest:row:{name}")

    provenance = captured.get("05_NOETHER_zh-Hans_PROVENANCE.zip", b"")
    provenance_members = 0
    provenance_manifest_members = 0
    provenance_member_bytes = 0
    provenance_inventory_sha256 = ""
    privacy_failures: list[str] = []
    secret_failures: list[str] = []
    if provenance:
        with zipfile.ZipFile(io.BytesIO(provenance)) as archive:
            bad = archive.testzip()
            if bad is not None:
                errors.append(f"provenance:crc:{bad}")
            names = archive.namelist()
            provenance_members = len(names)
            if "MANIFEST.csv" not in names:
                errors.append("provenance:manifest_absent")
                rows: list[dict[str, str]] = []
            else:
                rows = list(
                    csv.DictReader(io.StringIO(archive.read("MANIFEST.csv").decode("utf-8")))
                )
            provenance_manifest_members = len(rows)
            declared = {row["path"] for row in rows}
            actual = set(names) - {"MANIFEST.csv"}
            if declared != actual:
                errors.append("provenance:member_set")
            inventory_rows: list[str] = []
            for name in names:
                data = archive.read(name)
                provenance_member_bytes += len(data)
                inventory_rows.append(f"{name}\t{len(data)}\t{hashlib.sha256(data).hexdigest().upper()}\n")
                suffix = Path(name).suffix.lower()
                if suffix in TEXT_SUFFIXES or Path(name).name in {"VERSION", ".gitignore", ".gitattributes"}:
                    text = data.decode("utf-8")
                    if PRIVATE_NAME_RE.search(text):
                        privacy_failures.append(f"name:{name}")
                    if EMAIL_RE.search(text):
                        privacy_failures.append(f"email:{name}")
                for label, pattern in SECRET_PATTERNS.items():
                    if pattern.search(data):
                        secret_failures.append(f"{label}:{name}")
            for row in rows:
                data = archive.read(row["path"])
                if len(data) != int(row["bytes"]) or hashlib.sha256(data).hexdigest().upper() != row["sha256"]:
                    errors.append(f"provenance:identity:{row['path']}")
                if not row.get("source_sha256") or not row.get("source_bytes"):
                    errors.append(f"provenance:preimage:{row['path']}")
            provenance_inventory_sha256 = hashlib.sha256("".join(sorted(inventory_rows)).encode("utf-8")).hexdigest().upper()
    if privacy_failures:
        errors.extend(f"provenance:privacy:{item}" for item in privacy_failures)
    if secret_failures:
        errors.extend(f"provenance:secret:{item}" for item in secret_failures)

    versions_response = session.get(record["links"]["versions"], timeout=120)
    versions_response.raise_for_status()
    versions = sorted(
        str(item["metadata"]["version"])
        for item in versions_response.json()["hits"]["hits"]
    )
    if versions != ["1.0.0", "1.0.1", "1.0.2", "1.0.3"]:
        errors.append("versions")

    routes: list[dict[str, object]] = []
    for doi in (VERSION_DOI, CONCEPT_DOI):
        response = session.get(f"https://doi.org/{doi}", timeout=120)
        routes.append({"doi": doi, "http": response.status_code, "final": response.url})
        if response.status_code != 200 or not response.url.rstrip("/").endswith(f"/records/{RECORD_ID}"):
            errors.append(f"doi:{doi}")

    datacite: dict[str, object] | None = None
    for _ in range(10):
        response = session.get(f"https://api.datacite.org/dois/{VERSION_DOI}", timeout=60)
        if response.status_code == 200:
            datacite = response.json()
            break
        time.sleep(3)
    if datacite is None:
        errors.append("datacite:http")
        datacite_relations: list[tuple[object, object]] = []
    else:
        datacite_relations = sorted(
            (item.get("relationType"), item.get("relatedIdentifier"))
            for item in datacite["data"]["attributes"].get("relatedIdentifiers", [])
        )
        for required in (
            ("IsDerivedFrom", "10.5281/zenodo.21848304"),
            ("IsPartOf", "10.5281/zenodo.20412587"),
            ("IsSupplementedBy", "https://github.com/KokunoYumeto/emmy-noether-zh-hans"),
            ("IsVersionOf", CONCEPT_DOI),
        ):
            if required not in datacite_relations:
                errors.append(f"datacite:{required[0]}")

    inventory = json.dumps(identities, sort_keys=True, separators=(",", ":")).encode("utf-8")
    result = {
        "schema": "zh-noether-v103-public-audit-v1",
        "result": "PASS" if not errors else "FAIL",
        "record_id": RECORD_ID,
        "version_doi": VERSION_DOI,
        "concept_doi": CONCEPT_DOI,
        "version": metadata.get("version"),
        "files": len(files),
        "bytes": sum(int(item["bytes"]) for item in identities),
        "inventory_sha256": hashlib.sha256(inventory).hexdigest().upper(),
        "provenance_members": provenance_members,
        "provenance_manifest_members": provenance_manifest_members,
        "provenance_member_bytes": provenance_member_bytes,
        "provenance_inventory_sha256": provenance_inventory_sha256,
        "privacy_failures": privacy_failures,
        "secret_failures": secret_failures,
        "versions": versions,
        "doi_routes": routes,
        "relations": [list(item) for item in relations],
        "datacite_relations": [list(item) for item in datacite_relations],
        "errors": errors,
    }
    encoded = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    if args.output:
        target = args.output if args.output.is_absolute() else HERE / args.output
        target.write_text(encoded, encoding="utf-8", newline="\n")
    print(encoded, end="")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
