from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
SOURCE_DEPOSITION = 22172487


def request(url: str, token: str, method: str = "GET", data: bytes | None = None) -> tuple[int, bytes]:
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "zh-noether-v103-provenance/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Zenodo HTTP {exc.code}: {body}") from None


def main() -> int:
    if (HERE / "reserve.json").exists():
        raise SystemExit("reserve.json already exists; refusing a second reservation")
    token = TOKEN_PATH.read_text(encoding="utf-8").strip()
    if len(token) < 40 or any(ch.isspace() for ch in token):
        raise SystemExit("credential file did not contain one plausible token")
    status, body = request(
        f"https://zenodo.org/api/deposit/depositions/{SOURCE_DEPOSITION}/actions/newversion",
        token,
        method="POST",
        data=b"{}",
    )
    if status not in (201, 202):
        raise SystemExit(f"unexpected reserve status {status}")
    draft = json.loads(body)
    latest = draft.get("links", {}).get("latest_draft")
    if latest:
        _, latest_body = request(latest, token)
        draft = json.loads(latest_body)
    reserved = draft.get("metadata", {}).get("prereserve_doi", {})
    result = {
        "schema": "zh-noether-v103-reservation-v1",
        "result": "PASS",
        "source_deposition": SOURCE_DEPOSITION,
        "draft_id": draft.get("id"),
        "record_id": draft.get("record_id") or draft.get("id"),
        "reserved_doi": reserved.get("doi"),
        "reserved_recid": reserved.get("recid"),
        "bucket": draft.get("links", {}).get("bucket"),
        "html": draft.get("links", {}).get("html"),
        "inherited_files": [
            {
                "filename": item.get("filename"),
                "filesize": item.get("filesize"),
                "checksum": item.get("checksum"),
                "id": item.get("id"),
            }
            for item in draft.get("files", [])
        ],
        "metadata_title": draft.get("metadata", {}).get("title"),
        "metadata_version": draft.get("metadata", {}).get("version"),
        "response_sha256": hashlib.sha256(body).hexdigest().upper(),
        "credential_material_logged": False,
    }
    if not result["draft_id"] or not result["reserved_doi"] or not result["bucket"]:
        raise SystemExit("incomplete reservation response")
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    (HERE / "reserve.json").write_text(encoded, encoding="utf-8", newline="\n")
    print(
        json.dumps(
            {
                "result": "PASS",
                "draft_id": result["draft_id"],
                "reserved_doi": result["reserved_doi"],
                "inherited_files": len(result["inherited_files"]),
                "receipt_bytes": len(encoded.encode("utf-8")),
                "receipt_sha256": hashlib.sha256(encoded.encode("utf-8")).hexdigest().upper(),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
