from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
CHECKER = HERE.parents[1]
WORKSPACE = CHECKER.parents[4]
RELEASE = WORKSPACE / "03_projects/noether/10_zh/repo/release"
RESERVATION = HERE / "reserve.json"
OUTPUT = HERE / "03_NOETHER_zh-Hans_SHA256.txt"

EXPECTED = {
    "00_NOETHER_zh-Hans_COMPLETE_READER.pdf": (3169126, "0B6D9B78874325DE2C82C15FB07C6FE61DDB1A428E5F995A2F75D40961AA9079"),
    "01_NOETHER_zh-Hans_SOURCE.zip": (69998588, "D790F65B07E632D7E239C429444C1458523EAAF19CB81FEF8D9245351E8B1550"),
    "02_NOETHER_zh-Hans_EVIDENCE.zip": (1648561, "FE5B200E57C583710715D492072BEEC0504009732B6A3EEE2C3459CE90E22B9C"),
    "04_NOETHER_zh-Hans_R10B_BODY.pdf": (3129044, "0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544"),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def main() -> int:
    if not RESERVATION.is_file():
        raise SystemExit("reserve.json is absent")
    reservation = json.loads(RESERVATION.read_text(encoding="utf-8"))
    for name, (expected_bytes, expected_sha) in EXPECTED.items():
        path = RELEASE / name
        if path.stat().st_size != expected_bytes or sha256(path) != expected_sha:
            raise SystemExit(f"inherited asset mismatch: {name}")
    provenance = HERE / "05_NOETHER_zh-Hans_PROVENANCE.zip"
    if not provenance.is_file():
        raise SystemExit("provenance archive is absent")
    rows = [
        (name, expected_bytes, expected_sha)
        for name, (expected_bytes, expected_sha) in EXPECTED.items()
    ]
    rows.append((provenance.name, provenance.stat().st_size, sha256(provenance)))
    rows.sort()
    text = (
        "schema\tzh-noether-public-assets/1\n"
        "language_concept_doi\t10.5281/zenodo.21933034\n"
        f"exact_version_doi\t{reservation['reserved_doi']}\n"
        "version\t1.0.3\n"
        "name\tbytes\tsha256\n"
        + "".join(f"{name}\t{size}\t{digest}\n" for name, size, digest in rows)
    )
    OUTPUT.write_text(text, encoding="utf-8", newline="\n")
    result = {
        "schema": "zh-noether-v103-public-manifest-build-v1",
        "result": "PASS",
        "version": "1.0.3",
        "version_doi": reservation["reserved_doi"],
        "rows": len(rows),
        "bytes": OUTPUT.stat().st_size,
        "sha256": sha256(OUTPUT),
        "payload_bytes": sum(size for _, size, _ in rows),
    }
    encoded = json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n"
    (HERE / "sum.json").write_text(encoded, encoding="utf-8", newline="\n")
    print(encoded, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
