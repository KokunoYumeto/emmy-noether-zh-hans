from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import shutil
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
CHECKER = HERE.parents[1]
WORKSPACE = CHECKER.parents[4]
if WORKSPACE.name != "interlanguage":
    raise SystemExit("unexpected workspace root")

PRODUCER_ROOT = WORKSPACE / "03_projects/language_management/cjk/03_working_translations/zh_r10b"
LANE_ROOT = WORKSPACE / "03_projects/language_management/cjk/00_lane_control"
HANDOFF_ROOT = WORKSPACE / "04_handoffs/zh_r10b"
BACKEND_ROOT = WORKSPACE / "03_projects/cjk_notation"
REPO_ROOT = WORKSPACE / "03_projects/noether/10_zh/repo"
V101 = CHECKER / "pub/v101"
V102 = CHECKER / "pub/v102"
STAGE = HERE / "stage"
OUTPUT = HERE / "05_NOETHER_zh-Hans_PROVENANCE.zip"

TEXT_SUFFIXES = {".cff", ".csv", ".json", ".jsonl", ".md", ".py", ".tsv", ".txt"}
EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
PRIVATE_NAME_RE = re.compile(r"(?i)[USER]")
SECRET_PATTERNS = {
    "github_classic": re.compile(rb"ghp_[A-Za-z0-9]{20,}"),
    "github_fine_grained": re.compile(rb"github_pat_[A-Za-z0-9_]{20,}"),
    "jwt": re.compile(rb"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
    "assigned_secret": re.compile(
        rb"(?i)(?:access[_-]?token|api[_-]?key|password|secret)\s*[:=]\s*[\"']?[A-Za-z0-9_./+-]{16,}"
    ),
}
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def logical_source(path: Path) -> str:
    return path.relative_to(WORKSPACE).as_posix()


mapping: list[tuple[str, Path]] = []


def add(member: str, source: Path) -> None:
    mapping.append((member, source))


add("producer/translation_decision_log.md", LANE_ROOT / "CHINESE_DECISION_LOGBOOK_20260718.md")
for name in ("handoff.md", "manifest.csv", "return.json", "STATE.md"):
    add(f"producer/r10b/{name}", PRODUCER_ROOT / name)
for name in ("cleanup.json", "freeze.json", "v1.json", "v2.json"):
    add(f"producer/r10b/freeze/{name}", HANDOFF_ROOT / name)
for name in ("STATE.json", "decisions.jsonl", "TODO.md", "agents.jsonl"):
    add(f"producer/backend/{name}", BACKEND_ROOT / name)

add("checker/decision_log.md", CHECKER / "CHECKER_DECISION_LOG.md")
for name in (
    "README.md",
    "cleanup.json",
    "cleanup2.json",
    "cur.json",
    "cur2.json",
    "cur_check.py",
    "log.jsonl",
    "now.json",
    "raw.md",
):
    add(f"checker/state/{name}", CHECKER / "state" / name)
add("checker/backend/cjk_v112.json", CHECKER / "ref/cjk_v112.json")

for path in sorted((CHECKER / "r10b/ret").iterdir()):
    if path.is_file():
        add(f"checker/r10b/{path.name}", path)
for path in sorted(V101.iterdir()):
    if path.is_file():
        add(f"checker/publication_v101/{path.name}", path)
for path in sorted(V102.iterdir()):
    if path.is_file() and path.name != "05_NOETHER_zh-Hans_PROVENANCE.zip":
        add(f"checker/publication_v102/{path.name}", path)
for path in sorted((V102 / "meta").iterdir()):
    if path.is_file():
        add(f"checker/publication_v102/meta/{path.name}", path)

for name in ("agent.json", "gap.json", "intent.json", "build.py", "reserve.py", "sum.py", "stage.py", "verify.py", "publish.py", "audit.py"):
    add(f"checker/publication_v103/{name}", HERE / name)

for name in (
    ".gitattributes",
    ".gitignore",
    ".zenodo.json",
    "CHANGELOG.md",
    "CITATION.cff",
    "LICENSE",
    "PROVENANCE.md",
    "README.md",
    "VERSION",
):
    add(f"repository/{name}", REPO_ROOT / name)
add("repository/evidence/r10b/privacy.json", REPO_ROOT / "evidence/r10b/privacy.json")
add("backend/v112_public_audit.json", BACKEND_ROOT / "receipts/v112.audit.json")


def public_bytes(path: Path) -> tuple[bytes, str, int, int]:
    source = path.read_bytes()
    transform = "exact"
    private_name_replacements = 0
    email_replacements = 0
    if path.suffix.lower() in TEXT_SUFFIXES or path.name in {"VERSION", ".gitignore", ".gitattributes"}:
        text = source.decode("utf-8")
        text, email_replacements = EMAIL_RE.subn("[EMAIL]", text)
        text, private_name_replacements = PRIVATE_NAME_RE.subn("[USER]", text)
        result = text.encode("utf-8")
        if result != source:
            transform = "privacy_redaction_v1"
    else:
        result = source
    return result, transform, private_name_replacements, email_replacements


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir(parents=True)

    exact_token = b""
    if TOKEN_PATH.is_file():
        exact_token = TOKEN_PATH.read_bytes().strip()
        if len(exact_token) < 40:
            raise SystemExit("credential file did not contain one plausible token")

    seen: set[str] = set()
    folded: set[str] = set()
    rows: list[dict[str, object]] = []
    total_name_redactions = 0
    total_email_redactions = 0
    for member, source in mapping:
        if member in seen or member.casefold() in folded:
            raise SystemExit(f"duplicate member: {member}")
        seen.add(member)
        folded.add(member.casefold())
        if not source.is_file():
            raise SystemExit(f"missing source: {logical_source(source)}")
        source_data = source.read_bytes()
        data, transform, name_count, email_count = public_bytes(source)
        total_name_redactions += name_count
        total_email_redactions += email_count
        target = STAGE / member
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        rows.append(
            {
                "path": member,
                "bytes": len(data),
                "sha256": sha256(data),
                "source": logical_source(source),
                "source_bytes": len(source_data),
                "source_sha256": sha256(source_data),
                "transform": transform,
                "private_name_redactions": name_count,
                "email_redactions": email_count,
            }
        )

    readme = (
        "# Simplified-Chinese Noether cumulative provenance bundle\n\n"
        "This v1.0.3 bundle cumulatively preserves the Chinese translation decision "
        "log, independent-checker decisions and state through ZHCHK-D132 / "
        "STATE-20260830-044, producer backend consumption through CJK-NOT-D041, "
        "the accepted R10b freeze and return, publication evidence through v1.0.2, "
        "the exact static German-source relation, and the public repository metadata "
        "available before the v1.0.3 transaction.\n\n"
        "It excludes corpus duplication, page-render dumps, caches, credentials, and "
        "disposable scratch. Textual copies redact the local account holder's first "
        "name and email addresses. MANIFEST.csv binds every local source preimage to "
        "its public transformed bytes and excludes itself.\n\n"
        "The reader, source ZIP, evidence ZIP, and exact R10b body are inherited "
        "byte-for-byte. This is audit evidence, not a new translation, authority "
        "change, regional localization, or expanded backend-conformance claim.\n"
    ).encode("utf-8")
    (STAGE / "README.md").write_bytes(readme)
    rows.append(
        {
            "path": "README.md",
            "bytes": len(readme),
            "sha256": sha256(readme),
            "source": "generated",
            "source_bytes": len(readme),
            "source_sha256": sha256(readme),
            "transform": "generated",
            "private_name_redactions": 0,
            "email_redactions": 0,
        }
    )

    rows.sort(key=lambda row: str(row["path"]))
    manifest_io = io.StringIO(newline="")
    writer = csv.DictWriter(
        manifest_io,
        fieldnames=(
            "path",
            "bytes",
            "sha256",
            "source",
            "source_bytes",
            "source_sha256",
            "transform",
            "private_name_redactions",
            "email_redactions",
        ),
        lineterminator="\n",
    )
    writer.writeheader()
    writer.writerows(rows)
    manifest = manifest_io.getvalue().encode("utf-8")
    (STAGE / "MANIFEST.csv").write_bytes(manifest)

    name_failures: list[str] = []
    email_failures: list[str] = []
    token_failures: list[str] = []
    secret_failures: list[str] = []
    for path in sorted(STAGE.rglob("*")):
        if not path.is_file():
            continue
        data = path.read_bytes()
        rel = path.relative_to(STAGE).as_posix()
        if path.suffix.lower() in TEXT_SUFFIXES or path.name in {"VERSION", ".gitignore", ".gitattributes"}:
            text = data.decode("utf-8")
            if PRIVATE_NAME_RE.search(text):
                name_failures.append(rel)
            if EMAIL_RE.search(text):
                email_failures.append(rel)
        if exact_token and exact_token in data:
            token_failures.append(rel)
        for label, pattern in SECRET_PATTERNS.items():
            if pattern.search(data):
                secret_failures.append(f"{rel}:{label}")
    if name_failures or email_failures or token_failures or secret_failures:
        raise SystemExit(
            json.dumps(
                {
                    "name_failures": name_failures,
                    "email_failures": email_failures,
                    "token_failures": token_failures,
                    "secret_failures": secret_failures,
                },
                ensure_ascii=False,
            )
        )

    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(STAGE.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(STAGE).as_posix()
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    result = {
        "schema": "zh-noether-v103-provenance-build-v1",
        "result": "PASS",
        "archive": OUTPUT.name,
        "archive_bytes": OUTPUT.stat().st_size,
        "archive_sha256": sha256(OUTPUT.read_bytes()),
        "members": len(rows) + 1,
        "manifest_members": len(rows),
        "manifest_bytes": len(manifest),
        "manifest_sha256": sha256(manifest),
        "public_member_bytes": sum(int(row["bytes"]) for row in rows) + len(manifest),
        "source_member_bytes": sum(int(row["source_bytes"]) for row in rows),
        "privacy_redacted_files": sum(row["transform"] == "privacy_redaction_v1" for row in rows),
        "private_name_redactions": total_name_redactions,
        "email_redactions": total_email_redactions,
        "name_scan_failures": name_failures,
        "email_scan_failures": email_failures,
        "exact_token_scan_failures": token_failures,
        "secret_scan_failures": secret_failures,
        "credential_material_logged": False,
    }
    encoded = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    if args.receipt:
        target = args.receipt if args.receipt.is_absolute() else HERE / args.receipt
        target.write_text(encoded, encoding="utf-8", newline="\n")
    print(encoded, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
