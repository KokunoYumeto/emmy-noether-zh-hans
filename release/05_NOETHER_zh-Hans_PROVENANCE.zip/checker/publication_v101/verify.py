import argparse
import csv
import hashlib
import json
import os
import stat
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "manifest.csv"
MEMBERS = [
    "03_NOETHER_zh-Hans_SHA256.txt",
    "audit.json",
    "draft.json",
    "metadata.json",
    "pre.json",
    "public.json",
    "receipt.json",
    "v1.json",
    "v2.json",
    "verify.py",
]
EXCLUDED = {"manifest.csv", "verify1.json", "verify2.json"}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return h.hexdigest().upper()


def regular(path: Path) -> None:
    info = path.lstat()
    attrs = getattr(info, "st_file_attributes", 0)
    if stat.S_ISLNK(info.st_mode) or attrs & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise SystemExit(f"reparse point refused: {path}")
    if not stat.S_ISREG(info.st_mode):
        raise SystemExit(f"non-regular member refused: {path}")


def seal() -> None:
    if MANIFEST.exists():
        raise SystemExit("manifest already exists")
    rows = []
    for name in MEMBERS:
        path = ROOT / name
        regular(path)
        rows.append((name, path.stat().st_size, digest(path)))
    with MANIFEST.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["path", "bytes", "sha256"])
        writer.writerows(rows)


def verify(output: Path) -> None:
    regular(MANIFEST)
    rows = []
    with MANIFEST.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != ["path", "bytes", "sha256"]:
            raise SystemExit("manifest header mismatch")
        for row in reader:
            name = row["path"]
            pure = PurePosixPath(name)
            if pure.is_absolute() or "\\" in name or any(part in ("", ".", "..") for part in pure.parts):
                raise SystemExit(f"unsafe manifest path: {name}")
            rows.append((name, int(row["bytes"]), row["sha256"].upper()))
    names = [row[0] for row in rows]
    if names != MEMBERS or len(names) != len(set(names)) or len(names) != len({name.casefold() for name in names}):
        raise SystemExit("manifest member set/order/uniqueness mismatch")
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    allowed = set(MEMBERS) | EXCLUDED
    if actual - allowed or set(MEMBERS) - actual:
        raise SystemExit(f"root file-set mismatch: extra={sorted(actual-allowed)} missing={sorted(set(MEMBERS)-actual)}")
    checks = []
    for name, expected_bytes, expected_hash in rows:
        path = ROOT / name
        regular(path)
        actual_bytes = path.stat().st_size
        actual_hash = digest(path)
        if actual_bytes != expected_bytes or actual_hash != expected_hash:
            raise SystemExit(f"identity mismatch: {name}")
        checks.append({"path": name, "bytes": actual_bytes, "sha256": actual_hash})
    result = {
        "receipt_id": "ZHCHK-NOETHER-ZH-PUB-VERIFY-002",
        "status": "PASS",
        "manifest": {
            "bytes": MANIFEST.stat().st_size,
            "sha256": digest(MANIFEST),
            "entries": len(rows),
            "member_bytes": sum(row[1] for row in rows),
        },
        "checks": checks,
        "failures": 0,
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seal", action="store_true")
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.seal == args.verify:
        raise SystemExit("choose exactly one of --seal or --verify")
    if args.seal:
        seal()
    else:
        if args.output is None:
            raise SystemExit("--output is required")
        verify(args.output.resolve())


if __name__ == "__main__":
    main()
