from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import requests


HERE = Path(__file__).resolve().parent
V102 = HERE.parent
WORKSPACE = HERE.parents[7]
REPO = WORKSPACE / "03_projects" / "noether" / "10_zh" / "repo"

RECORD_ID = 22172487
VERSION_DOI = "10.5281/zenodo.22172487"
CONCEPT_DOI = "10.5281/zenodo.21933034"
SOURCE_RECORD_ID = 21848304
SOURCE_DOI = "10.5281/zenodo.21848304"
SOURCE_FILE = "20-de.tex"
SOURCE_BYTES = 2_153_594
SOURCE_SHA256 = "9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3"
REPOSITORY = "https://github.com/KokunoYumeto/emmy-noether-zh-hans"
MAIN_COMMIT = "F5345F4105F90168A50043399F49EB9E900E33F8"
TAG_OBJECT = "52545BD80896E428261B39D3EF284342D8A36AB5"
TAG_COMMIT = "58A2F37E8BFAAFE5D28E782A5F1B656A4DA55E5F"
RELEASE_ID = 379257314
EXPECTED_RELATIONS = [
    {
        "identifier": "10.5281/zenodo.20412587",
        "relation": "isPartOf",
        "resource_type": "dataset",
    },
    {
        "identifier": SOURCE_DOI,
        "relation": "isDerivedFrom",
        "resource_type": "dataset",
    },
    {
        "identifier": REPOSITORY,
        "relation": "isSupplementedBy",
        "resource_type": "software",
    },
]
SOURCE_NOTE = (
    '<p><strong>Exact German source provenance:</strong> This version derives from '
    '<code>20-de.tex</code> in Zenodo record '
    '<a href="https://doi.org/10.5281/zenodo.21848304">10.5281/zenodo.21848304</a>, '
    'authority <code>NOETH-DE-AUTH-v047-20260808 / ED0011</code>, '
    '2,153,594 bytes, SHA-256 '
    '<code>9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3</code>. '
    'The concept relation to 10.5281/zenodo.20412587 records membership in the '
    'multilingual collection.</p>'
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def canonical(value: object) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    errors: list[str] = []

    def check(condition: bool, label: str) -> None:
        if not condition:
            errors.append(label)

    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "zh-noether-v102-metadata-audit/1.0",
            "Accept": "application/json",
        }
    )

    record_response = session.get(
        f"https://zenodo.org/api/records/{RECORD_ID}", timeout=60
    )
    record_response.raise_for_status()
    record = record_response.json()
    metadata = record["metadata"]
    relations = metadata.get("related_identifiers", [])
    normalized_relations = [
        {
            key: item.get(key)
            for key in ("identifier", "relation", "resource_type")
        }
        for item in relations
    ]

    check(record.get("id") == RECORD_ID, "zenodo:record_id")
    check(record.get("doi") == VERSION_DOI, "zenodo:version_doi")
    check(record.get("conceptdoi") == CONCEPT_DOI, "zenodo:concept_doi")
    check(metadata.get("version") == "1.0.2", "zenodo:version")
    check(metadata.get("access_right") == "open", "zenodo:access")
    check(normalized_relations == EXPECTED_RELATIONS, "zenodo:relations")
    description = str(metadata.get("description", ""))
    source_fields = (
        SOURCE_FILE,
        SOURCE_DOI,
        "NOETH-DE-AUTH-v047-20260808 / ED0011",
        "2,153,594",
        SOURCE_SHA256,
    )
    check(all(value in description for value in source_fields), "zenodo:source_note")

    prior = json.loads((V102 / "github.json").read_text(encoding="utf-8"))
    expected_assets = {
        item["name"]: {
            "bytes": int(item["bytes"]),
            "md5": str(item["md5"]).upper(),
            "sha256": str(item["sha256"]).upper(),
        }
        for item in prior["assets"]
    }
    public_assets: dict[str, dict[str, object]] = {}
    for item in record.get("files", []):
        name = item["key"]
        public_assets[name] = {
            "bytes": int(item["size"]),
            "md5": str(item["checksum"]).removeprefix("md5:").upper(),
        }
    check(set(public_assets) == set(expected_assets), "zenodo:file_set")
    for name, expected in expected_assets.items():
        actual = public_assets.get(name, {})
        check(actual.get("bytes") == expected["bytes"], f"zenodo:bytes:{name}")
        check(actual.get("md5") == expected["md5"], f"zenodo:md5:{name}")

    checksum_name = "03_NOETHER_zh-Hans_SHA256.txt"
    checksum_file = next(item for item in record["files"] if item["key"] == checksum_name)
    checksum_response = session.get(checksum_file["links"]["self"], timeout=60)
    checksum_response.raise_for_status()
    check(
        len(checksum_response.content) == expected_assets[checksum_name]["bytes"],
        "zenodo:checksum_file_bytes",
    )
    check(
        sha256(checksum_response.content) == expected_assets[checksum_name]["sha256"],
        "zenodo:checksum_file_sha256",
    )

    source_response = session.get(
        f"https://zenodo.org/api/records/{SOURCE_RECORD_ID}/files/{SOURCE_FILE}/content",
        timeout=120,
    )
    source_response.raise_for_status()
    check(len(source_response.content) == SOURCE_BYTES, "source:bytes")
    check(sha256(source_response.content) == SOURCE_SHA256, "source:sha256")

    datacite_response = session.get(
        f"https://api.datacite.org/dois/{VERSION_DOI}", timeout=60
    )
    datacite_response.raise_for_status()
    datacite = datacite_response.json()["data"]["attributes"]
    datacite_relations = sorted(
        (item.get("relationType"), item.get("relatedIdentifier"))
        for item in datacite.get("relatedIdentifiers", [])
    )
    for required in (
        ("IsDerivedFrom", SOURCE_DOI),
        ("IsPartOf", "10.5281/zenodo.20412587"),
        ("IsSupplementedBy", REPOSITORY),
        ("IsVersionOf", CONCEPT_DOI),
    ):
        check(required in datacite_relations, f"datacite:{required[0]}")

    local_zenodo = (REPO / ".zenodo.json").read_bytes()
    local_zenodo_json = json.loads(local_zenodo)
    commit_raw_url = (
        "https://raw.githubusercontent.com/KokunoYumeto/emmy-noether-zh-hans/"
        f"{MAIN_COMMIT.lower()}/.zenodo.json"
    )
    raw_response = session.get(commit_raw_url, timeout=60)
    raw_response.raise_for_status()
    check(raw_response.content == local_zenodo, "github:raw_local_equality")
    check(
        local_zenodo_json.get("related_identifiers") == normalized_relations,
        "github:relations",
    )
    local_description = str(local_zenodo_json.get("description", ""))
    check(local_description.endswith(SOURCE_NOTE), "github:source_note")
    check(
        all(value in local_description for value in source_fields),
        "github:description",
    )

    commit_response = session.get(
        "https://api.github.com/repos/KokunoYumeto/emmy-noether-zh-hans/commits/main",
        timeout=60,
    )
    commit_response.raise_for_status()
    public_main = str(commit_response.json()["sha"]).upper()
    check(public_main == MAIN_COMMIT, "github:main_commit")

    ref_response = session.get(
        "https://api.github.com/repos/KokunoYumeto/emmy-noether-zh-hans/git/ref/tags/v1.0.2",
        timeout=60,
    )
    ref_response.raise_for_status()
    tag_object = str(ref_response.json()["object"]["sha"]).upper()
    check(tag_object == TAG_OBJECT, "github:tag_object")
    tag_response = session.get(
        f"https://api.github.com/repos/KokunoYumeto/emmy-noether-zh-hans/git/tags/{TAG_OBJECT.lower()}",
        timeout=60,
    )
    tag_response.raise_for_status()
    tag_commit = str(tag_response.json()["object"]["sha"]).upper()
    check(tag_commit == TAG_COMMIT, "github:tag_commit")

    release_response = session.get(
        "https://api.github.com/repos/KokunoYumeto/emmy-noether-zh-hans/releases/tags/v1.0.2",
        timeout=60,
    )
    release_response.raise_for_status()
    release = release_response.json()
    check(release.get("id") == RELEASE_ID, "github:release_id")
    check(not release.get("draft") and not release.get("prerelease"), "github:release_state")
    release_assets = {
        item["name"]: int(item["size"]) for item in release.get("assets", [])
    }
    check(
        release_assets
        == {name: item["bytes"] for name, item in expected_assets.items()},
        "github:release_assets",
    )

    versions_url = record.get("links", {}).get("versions")
    versions: list[str] = []
    if versions_url:
        versions_response = session.get(versions_url, timeout=60)
        versions_response.raise_for_status()
        versions_payload = versions_response.json()
        versions = sorted(
            str(item["metadata"]["version"])
            for item in versions_payload.get("hits", {}).get("hits", [])
        )
    check(versions == ["1.0.0", "1.0.1", "1.0.2"], "zenodo:versions")

    routes: list[dict[str, object]] = []
    for doi in (VERSION_DOI, CONCEPT_DOI):
        route_response = session.get(f"https://doi.org/{doi}", timeout=60)
        routes.append(
            {
                "doi": doi,
                "http": route_response.status_code,
                "final": route_response.url,
            }
        )
        check(route_response.status_code == 200, f"doi:http:{doi}")
        check(
            route_response.url.rstrip("/").endswith(f"/records/{RECORD_ID}"),
            f"doi:route:{doi}",
        )

    inventory = [
        {
            "name": name,
            "bytes": expected_assets[name]["bytes"],
            "md5": expected_assets[name]["md5"],
            "sha256": expected_assets[name]["sha256"],
        }
        for name in sorted(expected_assets)
    ]
    metadata_subset = {
        "doi": record["doi"],
        "conceptdoi": record["conceptdoi"],
        "version": metadata["version"],
        "description": description,
        "relations": normalized_relations,
    }
    result = {
        "schema": "zh-noether-v102-source-relation-audit-v1",
        "receipt_id": "ZHCHK-NOETHER-ZH-META-AUDIT-001",
        "result": "PASS" if not errors else "FAIL",
        "zenodo": {
            "record_id": RECORD_ID,
            "version_doi": VERSION_DOI,
            "concept_doi": CONCEPT_DOI,
            "version": metadata.get("version"),
            "access": metadata.get("access_right"),
            "relations": normalized_relations,
            "description_source_fields_exact_git_mirror": all(
                value in description and value in local_description
                for value in source_fields
            ),
            "public_description_sha256": sha256(description.encode("utf-8")),
            "git_description_sha256": sha256(local_description.encode("utf-8")),
            "metadata_subset_sha256": sha256(canonical(metadata_subset)),
            "files": len(inventory),
            "bytes": sum(int(item["bytes"]) for item in inventory),
            "inventory_sha256": sha256(canonical(inventory)),
            "versions": versions,
            "doi_routes": routes,
        },
        "source": {
            "doi": SOURCE_DOI,
            "record_id": SOURCE_RECORD_ID,
            "file": SOURCE_FILE,
            "bytes": len(source_response.content),
            "sha256": sha256(source_response.content),
        },
        "datacite_relations": [list(item) for item in datacite_relations],
        "github": {
            "repository": REPOSITORY,
            "main_commit": public_main,
            "zenodo_json_bytes": len(local_zenodo),
            "zenodo_json_sha256": sha256(local_zenodo),
            "tag": "v1.0.2",
            "tag_object": tag_object,
            "tag_commit": tag_commit,
            "release_id": release.get("id"),
            "release_files": len(release_assets),
            "release_bytes": sum(release_assets.values()),
        },
        "prior_receipts": {
            "metadata_edit_bytes": (HERE / "receipt.json").stat().st_size,
            "metadata_edit_sha256": sha256((HERE / "receipt.json").read_bytes()),
            "github_release_bytes": (V102 / "github.json").stat().st_size,
            "github_release_sha256": sha256((V102 / "github.json").read_bytes()),
        },
        "scope": {
            "public_file_bytes_changed": False,
            "new_zenodo_version_created": False,
            "release_tag_moved": False,
            "Chinese_changed": False,
            "German_changed": False,
            "Hant_changed": False,
            "SGA_changed": False,
        },
        "errors": errors,
    }
    encoded = json.dumps(
        result, ensure_ascii=False, sort_keys=True, indent=2
    ) + "\n"
    if args.output:
        output = args.output if args.output.is_absolute() else HERE / args.output
        output.write_text(encoded, encoding="utf-8", newline="\n")
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
