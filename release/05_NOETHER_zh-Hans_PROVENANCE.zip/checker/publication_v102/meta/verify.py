from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXCLUDED = {"manifest.csv", "v1.json", "v2.json"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    errors: list[str] = []
    rows = list(csv.DictReader((ROOT / "manifest.csv").open(encoding="utf-8", newline="")))
    declared = {row["path"] for row in rows}
    actual = {
        path.name
        for path in ROOT.iterdir()
        if path.is_file() and path.name not in EXCLUDED
    }
    if declared != actual:
        errors.append(
            "set:"
            + json.dumps(
                {"missing": sorted(declared - actual), "extra": sorted(actual - declared)},
                sort_keys=True,
                separators=(",", ":"),
            )
        )
    for row in rows:
        path = ROOT / row["path"]
        if not path.is_file():
            continue
        data = path.read_bytes()
        if len(data) != int(row["bytes"]):
            errors.append(f"bytes:{row['path']}")
        if sha256(data) != row["sha256"]:
            errors.append(f"sha256:{row['path']}")

    edit = json.loads((ROOT / "receipt.json").read_text(encoding="utf-8"))
    audit = json.loads((ROOT / "audit.json").read_text(encoding="utf-8"))
    failed = json.loads((ROOT / "audit0.json").read_text(encoding="utf-8"))
    agent = json.loads((ROOT / "agent.json").read_text(encoding="utf-8"))
    git = json.loads((ROOT / "git.json").read_text(encoding="utf-8"))
    if edit.get("result") != "PASS_METADATA_EDIT_PUBLISHED":
        errors.append("edit:result")
    if audit.get("result") != "PASS" or audit.get("errors") != []:
        errors.append("audit:result")
    if failed.get("result") != "FAIL" or failed.get("errors") != [
        "zenodo:relations",
        "github:relations",
        "github:description",
    ]:
        errors.append("audit0:history")
    if agent.get("result") != "PASS" or agent.get("workspace_files_modified") != 0:
        errors.append("agent:result")
    if git.get("result") != "PASS_PUBLIC_METADATA_MIRROR":
        errors.append("git:result")

    public = subprocess.run(
        [sys.executable, str(ROOT / "audit.py")],
        check=False,
        capture_output=True,
        text=True,
    )
    if public.returncode != 0:
        errors.append("public:returncode")
    else:
        try:
            replay = json.loads(public.stdout)
        except json.JSONDecodeError:
            errors.append("public:json")
        else:
            if replay != audit:
                errors.append("public:drift")

    result = {
        "schema": "zh-noether-v102-source-relation-verify-v1",
        "result": "PASS" if not errors else "FAIL",
        "manifest_members": len(rows),
        "manifest_member_bytes": sum(int(row["bytes"]) for row in rows),
        "manifest_sha256": sha256((ROOT / "manifest.csv").read_bytes()),
        "metadata_edit_sha256": sha256((ROOT / "receipt.json").read_bytes()),
        "audit_sha256": sha256((ROOT / "audit.json").read_bytes()),
        "git_receipt_sha256": sha256((ROOT / "git.json").read_bytes()),
        "failed_probe_preserved": True,
        "public_replay": "PASS" if "public:returncode" not in errors and "public:drift" not in errors else "FAIL",
        "errors": errors,
    }
    encoded = json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n"
    if args.output:
        output = args.output if args.output.is_absolute() else ROOT / args.output
        output.write_text(encoded, encoding="utf-8", newline="\n")
    print(encoded, end="")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
