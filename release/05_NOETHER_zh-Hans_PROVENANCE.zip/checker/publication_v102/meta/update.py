from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import requests


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
DEPOSITION_ID = 22172487
VERSION_DOI = "10.5281/zenodo.22172487"
SOURCE_RECORD_ID = 21848304
SOURCE_DOI = "10.5281/zenodo.21848304"
SOURCE_TEX_BYTES = 2_153_594
SOURCE_TEX_SHA256 = "9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3"
RELATION = {
    "identifier": SOURCE_DOI,
    "relation": "isDerivedFrom",
    "resource_type": "dataset",
}
SOURCE_NOTE = (
    '<p><strong>Exact German source provenance:</strong> This version derives from '
    '<code>20-de.tex</code> in Zenodo record '
    '<a href="https://doi.org/10.5281/zenodo.21848304">10.5281/zenodo.21848304</a>, '
    'authority <code>NOETH-DE-AUTH-v047-20260808 / ED0011</code>, '
    '2,153,594 bytes, SHA-256 '
    '<code>9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3</code>. '
    'The concept relation to 10.5281/zenodo.20412587 records membership in the '
    'multilingual collection.</p>'
)
EXPECTED_PRE_RELATIONS = [
    {
        "identifier": "10.5281/zenodo.20412587",
        "relation": "isPartOf",
        "resource_type": "dataset",
    },
    {
        "identifier": "https://github.com/KokunoYumeto/emmy-noether-zh-hans",
        "relation": "isSupplementedBy",
        "resource_type": "software",
    },
]
EXPECTED_POST_RELATIONS = [EXPECTED_PRE_RELATIONS[0], RELATION, EXPECTED_PRE_RELATIONS[1]]
DEPOSIT_URL = f"https://zenodo.org/api/deposit/depositions/{DEPOSITION_ID}"
PUBLIC_URL = f"https://zenodo.org/api/records/{DEPOSITION_ID}"
SOURCE_URL = f"https://zenodo.org/api/records/{SOURCE_RECORD_ID}"
DATACITE_URL = f"https://api.datacite.org/dois/{VERSION_DOI}"
USER_AGENT = "zh-noether-source-relation/1.0"


def canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def clean_relation(value: dict[str, object]) -> dict[str, object]:
    return {
        key: value[key]
        for key in ("identifier", "relation", "resource_type")
        if value.get(key) is not None
    }


def normalized_relations(metadata: dict[str, object]) -> list[dict[str, object]]:
    return [clean_relation(item) for item in metadata.get("related_identifiers", [])]


def verify_public(
    session: requests.Session,
    expected_assets: dict[str, dict[str, object]],
) -> tuple[dict[str, object], dict[str, object]]:
    response = session.get(PUBLIC_URL, timeout=60)
    response.raise_for_status()
    record = response.json()
    relations = normalized_relations(record["metadata"])
    if relations != EXPECTED_POST_RELATIONS:
        raise RuntimeError(f"public relations mismatch: {relations!r}")
    description = str(record["metadata"].get("description", ""))
    if SOURCE_DOI not in description or SOURCE_TEX_SHA256 not in description:
        raise RuntimeError("public source-provenance description is incomplete")
    files = {item["key"]: item for item in record["files"]}
    if set(files) != set(expected_assets):
        raise RuntimeError("public asset-name set changed")
    for name, expected in expected_assets.items():
        actual = files[name]
        checksum = str(actual["checksum"])
        if checksum.startswith("md5:"):
            checksum = checksum[4:]
        if int(actual["size"]) != int(expected["bytes"]):
            raise RuntimeError(f"public asset bytes changed: {name}")
        if checksum.upper() != str(expected["md5"]).upper():
            raise RuntimeError(f"public asset MD5 changed: {name}")
    datacite_response = session.get(DATACITE_URL, timeout=60)
    datacite_response.raise_for_status()
    datacite = datacite_response.json()
    related = datacite["data"]["attributes"].get("relatedIdentifiers", [])
    source_hits = [
        item
        for item in related
        if item.get("relatedIdentifier") == SOURCE_DOI
        and str(item.get("relationType", "")).lower() == "isderivedfrom"
    ]
    if len(source_hits) != 1:
        raise RuntimeError(f"DataCite source relation mismatch: {source_hits!r}")
    return record, datacite


def main() -> None:
    dry_run = "--dry-run" in sys.argv[1:]
    token = TOKEN_PATH.read_text(encoding="utf-8").strip()
    if not token:
        raise RuntimeError("empty Zenodo token")
    session = requests.Session()
    session.headers.update(
        {"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT}
    )
    public_session = requests.Session()
    public_session.headers.update({"User-Agent": USER_AGENT})

    github_receipt = json.loads(
        (HERE.parent / "github.json").read_text(encoding="utf-8")
    )
    expected_assets = {item["name"]: item for item in github_receipt["assets"]}

    source_response = public_session.get(SOURCE_URL, timeout=60)
    source_response.raise_for_status()
    source_record = source_response.json()
    if source_record.get("doi") != SOURCE_DOI:
        raise RuntimeError("source record DOI mismatch")
    if "ED0011/v047" not in str(source_record["metadata"].get("version", "")):
        raise RuntimeError("source record does not identify ED0011/v047")
    source_file = next(
        item for item in source_record["files"] if item["key"] == "20-de.tex"
    )
    source_tex_response = public_session.get(source_file["links"]["self"], timeout=90)
    source_tex_response.raise_for_status()
    source_tex = source_tex_response.content
    if len(source_tex) != SOURCE_TEX_BYTES or sha256(source_tex) != SOURCE_TEX_SHA256:
        raise RuntimeError("source German bytes do not match ED0011")

    deposition_response = session.get(DEPOSIT_URL, timeout=60)
    deposition_response.raise_for_status()
    deposition = deposition_response.json()
    if deposition.get("state") != "done" or deposition.get("submitted") is not True:
        raise RuntimeError("Chinese deposition is not in published done state")
    metadata = deposition["metadata"]
    if metadata.get("version") != "1.0.2" or metadata.get("doi") != VERSION_DOI:
        raise RuntimeError("Chinese deposition identity mismatch")
    pre_relations = normalized_relations(metadata)
    if pre_relations not in (EXPECTED_PRE_RELATIONS, EXPECTED_POST_RELATIONS):
        raise RuntimeError(f"unexpected pre-edit relation set: {pre_relations!r}")
    forbidden = "Translation and Transcription Project"
    private_name = "".join(chr(value) for value in (70, 108, 111, 114, 105, 115))
    public_text = json.dumps(metadata, ensure_ascii=False)
    if "TTP" in public_text or forbidden in public_text or private_name in public_text:
        raise RuntimeError("forbidden metadata text detected")

    pre = {
        "schema": "zh-noether-v102-source-relation-pre-v1",
        "record_id": DEPOSITION_ID,
        "doi": VERSION_DOI,
        "state": deposition["state"],
        "submitted": deposition["submitted"],
        "metadata_sha256": sha256(canonical_bytes(metadata)),
        "relations": pre_relations,
        "description_has_static_source": SOURCE_DOI in str(metadata.get("description", "")),
        "files": [
            {
                "name": item["name"],
                "bytes": item["bytes"],
                "sha256": item["sha256"],
                "md5": item["md5"],
            }
            for item in github_receipt["assets"]
        ],
        "source": {
            "record_id": SOURCE_RECORD_ID,
            "doi": SOURCE_DOI,
            "version": source_record["metadata"]["version"],
            "file": "20-de.tex",
            "bytes": len(source_tex),
            "sha256": sha256(source_tex),
        },
        "credential_material_logged": False,
    }
    (HERE / "pre.json").write_bytes(
        json.dumps(pre, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    )

    if dry_run:
        encoded = (HERE / "pre.json").read_bytes()
        print(
            json.dumps(
                {
                    "result": "PASS_PREFLIGHT",
                    "pre_bytes": len(encoded),
                    "pre_sha256": sha256(encoded),
                    "relations_before": pre_relations,
                    "relation_to_add": RELATION,
                    "description_note_needed": SOURCE_DOI
                    not in str(metadata.get("description", "")),
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        )
        return

    description_complete = SOURCE_DOI in str(metadata.get("description", ""))
    if pre_relations == EXPECTED_POST_RELATIONS and description_complete:
        public_record, datacite = verify_public(public_session, expected_assets)
        result = "PASS_ALREADY_PRESENT"
        http = {"edit": None, "update": None, "publish": None}
    else:
        edit_started = False
        try:
            edit_response = session.post(f"{DEPOSIT_URL}/actions/edit", json={}, timeout=60)
            edit_response.raise_for_status()
            edit_started = True
            target_metadata = dict(metadata)
            target_metadata["related_identifiers"] = EXPECTED_POST_RELATIONS
            description = str(target_metadata.get("description", ""))
            if SOURCE_DOI not in description:
                target_metadata["description"] = description + SOURCE_NOTE
            update_response = session.put(
                DEPOSIT_URL, json={"metadata": target_metadata}, timeout=60
            )
            update_response.raise_for_status()
            updated = update_response.json()
            if normalized_relations(updated["metadata"]) != EXPECTED_POST_RELATIONS:
                raise RuntimeError("draft update relation verification failed")
            publish_response = session.post(
                f"{DEPOSIT_URL}/actions/publish", json={}, timeout=90
            )
            publish_response.raise_for_status()
            http = {
                "edit": edit_response.status_code,
                "update": update_response.status_code,
                "publish": publish_response.status_code,
            }
        except Exception:
            if edit_started:
                try:
                    session.post(f"{DEPOSIT_URL}/actions/discard", json={}, timeout=60)
                except Exception:
                    pass
            raise
        result = "PASS_METADATA_EDIT_PUBLISHED"
        public_record = None
        datacite = None
        for _ in range(20):
            try:
                public_record, datacite = verify_public(public_session, expected_assets)
                break
            except Exception:
                time.sleep(1)
        if public_record is None or datacite is None:
            raise RuntimeError("public or DataCite post-edit verification did not converge")

    post_metadata = public_record["metadata"]
    post = {
        "schema": "zh-noether-v102-source-relation-post-v1",
        "record_id": public_record["id"],
        "doi": public_record["doi"],
        "conceptdoi": public_record["conceptdoi"],
        "version": post_metadata["version"],
        "relations": normalized_relations(post_metadata),
        "metadata_sha256": sha256(canonical_bytes(post_metadata)),
        "public_files": len(public_record["files"]),
        "public_bytes": sum(int(item["size"]) for item in public_record["files"]),
        "datacite_relation": RELATION,
        "credential_material_logged": False,
    }
    (HERE / "post.json").write_bytes(
        json.dumps(post, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    )
    receipt = {
        "receipt_id": "ZHCHK-NOETHER-ZH-META-001",
        "result": result,
        "record_id": DEPOSITION_ID,
        "doi": VERSION_DOI,
        "http": http,
        "added_relation": RELATION,
        "description_provenance_added": SOURCE_DOI
        not in str(metadata.get("description", "")),
        "source_german": pre["source"],
        "public_relations": post["relations"],
        "public_files": post["public_files"],
        "public_bytes": post["public_bytes"],
        "pre_bytes": (HERE / "pre.json").stat().st_size,
        "pre_sha256": sha256((HERE / "pre.json").read_bytes()),
        "post_bytes": (HERE / "post.json").stat().st_size,
        "post_sha256": sha256((HERE / "post.json").read_bytes()),
        "files_unchanged": True,
        "relation_vocabulary_evidence": "https://developers.zenodo.org/#representation",
        "isTranslationOf_supported_by_legacy_api": False,
        "credential_material_logged": False,
    }
    encoded = json.dumps(receipt, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    (HERE / "receipt.json").write_bytes(encoded)
    print(
        json.dumps(
            {
                "result": result,
                "receipt_bytes": len(encoded),
                "receipt_sha256": sha256(encoded),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
    )


if __name__ == "__main__":
    main()
