from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import PurePosixPath


RECORD_ID = 22172487
VERSION_DOI = "10.5281/zenodo.22172487"
CONCEPT_DOI = "10.5281/zenodo.21933034"
EXPECTED = {
    "00_NOETHER_zh-Hans_COMPLETE_READER.pdf": (
        3169126,
        "0B6D9B78874325DE2C82C15FB07C6FE61DDB1A428E5F995A2F75D40961AA9079",
    ),
    "01_NOETHER_zh-Hans_SOURCE.zip": (
        69998588,
        "D790F65B07E632D7E239C429444C1458523EAAF19CB81FEF8D9245351E8B1550",
    ),
    "02_NOETHER_zh-Hans_EVIDENCE.zip": (
        1648561,
        "FE5B200E57C583710715D492072BEEC0504009732B6A3EEE2C3459CE90E22B9C",
    ),
    "03_NOETHER_zh-Hans_SHA256.txt": (
        686,
        "124F6EBBE89B1A70071C425EBBB19E9AB0CA186876C87C9FEF1B0E4FA8E31283",
    ),
    "04_NOETHER_zh-Hans_R10B_BODY.pdf": (
        3129044,
        "0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544",
    ),
    "05_NOETHER_zh-Hans_PROVENANCE.zip": (
        577746,
        "5BF76D218CAAF9D76C7986DA73CF04607A27AA86E1812F5B10FFA9E6FDD7C57A",
    ),
}
NAME_RE = re.compile(r"(?i)[USER]")
SECRET_PATTERNS = {
    "github_classic": re.compile(rb"ghp_[A-Za-z0-9]{20,}"),
    "github_fine_grained": re.compile(rb"github_pat_[A-Za-z0-9_]{20,}"),
    "jwt": re.compile(rb"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
    "assigned_secret": re.compile(
        rb"(?i)(?:access[_-]?token|api[_-]?key|password|secret)\s*[:=]\s*[\"']?[A-Za-z0-9_./+-]{16,}"
    ),
}
TEXT_SUFFIXES = {".csv", ".json", ".jsonl", ".md", ".py", ".tsv", ".txt"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def get(url: str) -> tuple[bytes, str, int]:
    req = urllib.request.Request(
        url, headers={"User-Agent": "zh-noether-public-audit/1.0"}
    )
    try:
        with urllib.request.urlopen(req, timeout=300) as response:
            return response.read(), response.geturl(), response.status
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {exc.code} {url}: {body}") from None


api_body, _, api_http = get(f"https://zenodo.org/api/records/{RECORD_ID}")
record = json.loads(api_body)
errors: list[str] = []
if api_http != 200:
    errors.append("api:http")
if record.get("status") != "published":
    errors.append("api:status")
if record.get("doi") != VERSION_DOI or record.get("conceptdoi") != CONCEPT_DOI:
    errors.append("api:doi")
metadata = record.get("metadata", {})
if metadata.get("version") != "1.0.2":
    errors.append("metadata:version")
if metadata.get("access_right") != "open":
    errors.append("metadata:access")
description = str(metadata.get("description", ""))
if "Version 1.0.2 provenance successor" not in description:
    errors.append("metadata:description")
if "TTP" in description or "Translation and Transcription Project" in description:
    errors.append("metadata:forbidden_project_label")
if NAME_RE.search(description):
    errors.append("metadata:private_name")

api_files = {item["key"]: item for item in record.get("files", [])}
if set(api_files) != set(EXPECTED):
    errors.append(
        "file_set:" + json.dumps(
            {
                "missing": sorted(set(EXPECTED) - set(api_files)),
                "extra": sorted(set(api_files) - set(EXPECTED)),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
    )
downloads: dict[str, bytes] = {}
rows = []
for name, (expected_bytes, expected_sha) in EXPECTED.items():
    item = api_files.get(name)
    if item is None:
        continue
    data, _, http = get(
        f"https://zenodo.org/records/{RECORD_ID}/files/{urllib.parse.quote(name, safe='')}?download=1"
    )
    downloads[name] = data
    actual_sha = sha256(data)
    md5 = hashlib.md5(data).hexdigest().lower()
    if http != 200:
        errors.append(f"http:{name}")
    if len(data) != expected_bytes or len(data) != int(item["size"]):
        errors.append(f"bytes:{name}")
    if actual_sha != expected_sha:
        errors.append(f"sha256:{name}")
    if item["checksum"].lower() != "md5:" + md5:
        errors.append(f"md5:{name}")
    rows.append(f"{name}\t{len(data)}\t{actual_sha}\n")

manifest = downloads.get("03_NOETHER_zh-Hans_SHA256.txt", b"").decode("utf-8")
manifest_lines = manifest.splitlines()
try:
    header_index = manifest_lines.index("name\tbytes\tsha256")
except ValueError:
    errors.append("manifest:header")
    manifest_rows = []
else:
    manifest_rows = list(
        csv.DictReader(io.StringIO("\n".join(manifest_lines[header_index:]) + "\n"), delimiter="\t")
    )
manifest_names = {row["name"] for row in manifest_rows}
if manifest_names != set(EXPECTED) - {"03_NOETHER_zh-Hans_SHA256.txt"}:
    errors.append("manifest:set")
for row in manifest_rows:
    name = row["name"]
    data = downloads.get(name)
    if data is None:
        continue
    if len(data) != int(row["bytes"]) or sha256(data) != row["sha256"]:
        errors.append(f"manifest:identity:{name}")
if "exact_version_doi\t" + VERSION_DOI not in manifest:
    errors.append("manifest:doi")
if "version\t1.0.2" not in manifest:
    errors.append("manifest:version")

provenance = downloads.get("05_NOETHER_zh-Hans_PROVENANCE.zip", b"")
zip_members: dict[str, bytes] = {}
try:
    with zipfile.ZipFile(io.BytesIO(provenance), "r") as archive:
        bad_crc = archive.testzip()
        if bad_crc:
            errors.append(f"provenance:crc:{bad_crc}")
        seen: set[str] = set()
        for info in archive.infolist():
            name = info.filename
            if name.endswith("/"):
                errors.append(f"provenance:directory:{name}")
                continue
            parts = PurePosixPath(name).parts
            if not parts or name.startswith("/") or ".." in parts or "\\" in name:
                errors.append(f"provenance:unsafe:{name}")
            if name.casefold() in seen:
                errors.append(f"provenance:duplicate:{name}")
            seen.add(name.casefold())
            zip_members[name] = archive.read(info)
except zipfile.BadZipFile:
    errors.append("provenance:bad_zip")

if len(zip_members) != 46:
    errors.append("provenance:member_count")
if "MANIFEST.csv" not in zip_members:
    errors.append("provenance:manifest_missing")
    provenance_rows = []
else:
    provenance_rows = list(
        csv.DictReader(io.StringIO(zip_members["MANIFEST.csv"].decode("utf-8"), newline=""))
    )
if len(provenance_rows) != 45:
    errors.append("provenance:manifest_count")
declared = {row["path"] for row in provenance_rows}
if declared != set(zip_members) - {"MANIFEST.csv"}:
    errors.append("provenance:manifest_set")
for row in provenance_rows:
    data = zip_members.get(row["path"])
    if data is None:
        continue
    if len(data) != int(row["bytes"]) or sha256(data) != row["sha256"]:
        errors.append(f"provenance:identity:{row['path']}")
for name, data in zip_members.items():
    if PurePosixPath(name).suffix.lower() in TEXT_SUFFIXES:
        text = data.decode("utf-8")
        if NAME_RE.search(text):
            errors.append(f"provenance:private_name:{name}")
    for label, pattern in SECRET_PATTERNS.items():
        if pattern.search(data):
            errors.append(f"provenance:secret:{label}:{name}")

routes = []
for doi, expected_record in ((VERSION_DOI, RECORD_ID), (CONCEPT_DOI, RECORD_ID)):
    _, final_url, http = get("https://doi.org/" + doi)
    if http != 200 or not final_url.rstrip("/").endswith(f"/records/{expected_record}"):
        errors.append(f"doi:{doi}")
    routes.append({"doi": doi, "http": http, "final": final_url})

datacite_body, _, datacite_http = get(
    "https://api.datacite.org/dois/" + VERSION_DOI
)
if datacite_http != 200:
    errors.append("datacite:http")
datacite = json.loads(datacite_body)
relations = sorted(
    (
        item.get("relationType"),
        item.get("relatedIdentifier"),
    )
    for item in datacite.get("data", {}).get("attributes", {}).get("relatedIdentifiers", [])
)
required_relations = {
    ("IsPartOf", "10.5281/zenodo.20412587"),
    ("IsVersionOf", CONCEPT_DOI),
}
if not required_relations.issubset(set(relations)):
    errors.append("datacite:relations")

inventory = "".join(sorted(rows)).encode("utf-8")
zip_inventory = "".join(
    f"{name}\t{len(data)}\t{sha256(data)}\n"
    for name, data in sorted(zip_members.items())
).encode("utf-8")
result = {
    "schema": "zh-noether-v102-public-verify-v1",
    "result": "PASS" if not errors else "FAIL",
    "record_id": RECORD_ID,
    "version_doi": VERSION_DOI,
    "concept_doi": CONCEPT_DOI,
    "files": len(api_files),
    "bytes": sum(len(data) for data in downloads.values()),
    "inventory_sha256": sha256(inventory),
    "provenance_members": len(zip_members),
    "provenance_inventory_sha256": sha256(zip_inventory),
    "doi_routes": routes,
    "datacite_relations": [list(item) for item in relations],
    "errors": errors,
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
raise SystemExit(0 if not errors else 1)
