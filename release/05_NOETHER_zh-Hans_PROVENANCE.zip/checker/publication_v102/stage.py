from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
RESERVATION = json.loads((HERE / "reserve.json").read_text(encoding="utf-8"))
DRAFT_ID = int(RESERVATION["draft_id"])
BUCKET = str(RESERVATION["bucket"]).rstrip("/")
MANIFEST_NAME = "03_NOETHER_zh-Hans_SHA256.txt"
PROVENANCE_NAME = "05_NOETHER_zh-Hans_PROVENANCE.zip"
TOKEN = TOKEN_PATH.read_text(encoding="utf-8").strip()
if len(TOKEN) < 40 or any(ch.isspace() for ch in TOKEN):
    raise SystemExit("credential file did not contain one plausible token")


def request(
    url: str,
    method: str = "GET",
    data: bytes | None = None,
    content_type: str = "application/json",
) -> tuple[int, bytes]:
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": content_type,
            "User-Agent": "zh-noether-provenance-release/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Zenodo HTTP {exc.code}: {body}") from None


def draft() -> dict:
    _, body = request(f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}")
    return json.loads(body)


current = draft()
for item in current.get("files", []):
    if item.get("filename") == MANIFEST_NAME:
        status, _ = request(
            f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}/files/{item['id']}",
            method="DELETE",
        )
        if status not in (200, 202, 204):
            raise SystemExit(f"unexpected delete status {status}")

uploads = []
for name in (PROVENANCE_NAME, MANIFEST_NAME):
    data = (HERE / name).read_bytes()
    url = BUCKET + "/" + urllib.parse.quote(name, safe="")
    status, body = request(
        url,
        method="PUT",
        data=data,
        content_type="application/octet-stream",
    )
    if status not in (200, 201):
        raise SystemExit(f"unexpected upload status {status} for {name}")
    uploads.append(
        {
            "name": name,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest().upper(),
            "response_sha256": hashlib.sha256(body).hexdigest().upper(),
        }
    )

current = draft()
metadata = dict(current["metadata"])
metadata["version"] = "1.0.2"
metadata["publication_date"] = "2026-08-30"
description = str(metadata.get("description", ""))
description = description.replace(
    "https://zenodo.org/records/21933035/files/00_NOETHER_zh-Hans_COMPLETE_READER.pdf",
    f"https://zenodo.org/records/{DRAFT_ID}/files/00_NOETHER_zh-Hans_COMPLETE_READER.pdf",
)
note = (
    "<p><strong>Version 1.0.2 provenance successor (2026-08-30):</strong> "
    "adds <code>05_NOETHER_zh-Hans_PROVENANCE.zip</code> (SHA-256 "
    "<code>5BF76D218CAAF9D76C7986DA73CF04607A27AA86E1812F5B10FFA9E6FDD7C57A</code>) "
    "with the complete Chinese producer decision log, the complete independent-checker "
    "decision/event state, accepted R10b return and freeze controls, and the v1.0.1 "
    "publication/backend receipts available before this transaction. Textual public "
    "copies redact the local account holder's first name and email addresses; the "
    "internal manifest binds every local source preimage hash to its public transformed "
    "hash. The reader, source ZIP, evidence ZIP, and exact R10b body are inherited "
    "byte-for-byte; no Chinese wording, mathematics, authority binding, or regional-"
    "localization claim changed.</p>"
)
if "Version 1.0.2 provenance successor" not in description:
    description += note
metadata["description"] = description
status, body = request(
    f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}",
    method="PUT",
    data=json.dumps({"metadata": metadata}, ensure_ascii=False).encode("utf-8"),
)
if status != 200:
    raise SystemExit(f"unexpected metadata status {status}")

result = {
    "schema": "zh-noether-v102-stage-v1",
    "result": "PASS",
    "draft_id": DRAFT_ID,
    "reserved_doi": RESERVATION["reserved_doi"],
    "uploads": uploads,
    "metadata_status": status,
    "metadata_response_sha256": hashlib.sha256(body).hexdigest().upper(),
    "credential_material_logged": False,
}
encoded = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
(HERE / "stage.json").write_bytes(encoded)
print(
    json.dumps(
        {
            "result": "PASS",
            "draft_id": DRAFT_ID,
            "uploads": len(uploads),
            "receipt_bytes": len(encoded),
            "receipt_sha256": hashlib.sha256(encoded).hexdigest().upper(),
        },
        sort_keys=True,
        separators=(",", ":"),
    )
)
