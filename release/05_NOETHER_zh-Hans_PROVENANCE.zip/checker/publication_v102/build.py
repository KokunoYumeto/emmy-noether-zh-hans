from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import shutil
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
CHECKER = HERE.parents[1]
WORKSPACE = CHECKER.parents[4]
if WORKSPACE.name != "interlanguage":
    raise SystemExit("unexpected workspace root")

PRODUCER_ROOT = (
    WORKSPACE
    / "03_projects/language_management/cjk/03_working_translations/zh_r10b"
)
LANE_ROOT = WORKSPACE / "03_projects/language_management/cjk/00_lane_control"
HANDOFF_ROOT = WORKSPACE / "04_handoffs/zh_r10b"
BACKEND_ROOT = WORKSPACE / "03_projects/cjk_notation"
STAGE = HERE / "stage"
OUTPUT = HERE / "05_NOETHER_zh-Hans_PROVENANCE.zip"

TEXT_SUFFIXES = {".csv", ".json", ".jsonl", ".md", ".py", ".tsv", ".txt"}
EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
NAME_RE = re.compile(r"(?i)[USER]")
SECRET_PATTERNS = {
    "github_classic": re.compile(rb"ghp_[A-Za-z0-9]{20,}"),
    "github_fine_grained": re.compile(rb"github_pat_[A-Za-z0-9_]{20,}"),
    "jwt": re.compile(rb"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
    "assigned_secret": re.compile(
        rb"(?i)(?:access[_-]?token|api[_-]?key|password|secret)\s*[:=]\s*[\"']?[A-Za-z0-9_./+-]{16,}"
    ),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def add(mapping: list[tuple[str, Path]], member: str, source: Path) -> None:
    mapping.append((member, source))


mapping: list[tuple[str, Path]] = []
add(
    mapping,
    "producer/decision_log.md",
    LANE_ROOT / "CHINESE_DECISION_LOGBOOK_20260718.md",
)
for name in ("handoff.md", "manifest.csv", "return.json", "STATE.md"):
    add(mapping, f"producer/r10b/{name}", PRODUCER_ROOT / name)
for name in ("cleanup.json", "freeze.json", "v1.json", "v2.json"):
    add(mapping, f"producer/r10b/freeze/{name}", HANDOFF_ROOT / name)

add(mapping, "checker/decision_log.md", CHECKER / "CHECKER_DECISION_LOG.md")
for name in ("raw.md", "log.jsonl", "now.json", "cur.json"):
    add(mapping, f"checker/state/{name}", CHECKER / "state" / name)
add(mapping, "checker/backend/cjk_v112.json", CHECKER / "ref/cjk_v112.json")

for name in (
    "build.json",
    "cleanup.json",
    "cust.json",
    "delta.json",
    "fix.json",
    "manifest.csv",
    "pdf.json",
    "policy.md",
    "prior.json",
    "receipt.json",
    "render.json",
    "report.json",
    "v1.json",
    "v2.json",
    "verify.py",
):
    add(mapping, f"checker/r10b/{name}", CHECKER / "r10b/ret" / name)

for name in (
    "03_NOETHER_zh-Hans_SHA256.txt",
    "audit.json",
    "draft.json",
    "manifest.csv",
    "metadata.json",
    "pre.json",
    "public.json",
    "receipt.json",
    "v1.json",
    "v2.json",
    "verify.py",
    "verify1.json",
    "verify2.json",
):
    add(mapping, f"checker/publication_v101/{name}", CHECKER / "pub/v101" / name)

add(
    mapping,
    "backend/v112_public_audit.json",
    BACKEND_ROOT / "receipts/v112.audit.json",
)


def logical_source(path: Path) -> str:
    return path.relative_to(WORKSPACE).as_posix()


def public_bytes(path: Path) -> tuple[bytes, str, int, int]:
    source = path.read_bytes()
    transform = "exact"
    name_replacements = 0
    email_replacements = 0
    if path.suffix.lower() in TEXT_SUFFIXES:
        text = source.decode("utf-8")
        text, email_replacements = EMAIL_RE.subn("[EMAIL]", text)
        text, name_replacements = NAME_RE.subn("[USER]", text)
        result = text.encode("utf-8")
        if result != source:
            transform = "privacy_redaction_v1"
    else:
        result = source
    return result, transform, name_replacements, email_replacements


if STAGE.exists():
    shutil.rmtree(STAGE)
STAGE.mkdir(parents=True)

seen: set[str] = set()
rows: list[dict[str, object]] = []
total_name_redactions = 0
total_email_redactions = 0
for member, source in mapping:
    if member in seen or member.casefold() in {item.casefold() for item in seen}:
        raise SystemExit(f"duplicate member: {member}")
    seen.add(member)
    if not source.is_file():
        raise SystemExit(f"missing source: {logical_source(source)}")
    source_data = source.read_bytes()
    data, transform, name_count, email_count = public_bytes(source)
    total_name_redactions += name_count
    total_email_redactions += email_count
    target = STAGE / member
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    rows.append(
        {
            "path": member,
            "bytes": len(data),
            "sha256": sha256(data),
            "source": logical_source(source),
            "source_bytes": len(source_data),
            "source_sha256": sha256(source_data),
            "transform": transform,
            "name_redactions": name_count,
            "email_redactions": email_count,
        }
    )

readme = (
    "# Simplified-Chinese Noether provenance bundle\n\n"
    "This additive bundle preserves the complete Chinese producer decision log, "
    "the complete independent-checker decision/event state, the accepted R10b "
    "return, freeze and verifier controls, and the v1.0.1 publication/backend "
    "receipts available before the v1.0.2 transaction.\n\n"
    "It intentionally excludes corpus duplication, rendered-page dumps, build "
    "caches, credentials, and disposable scratch. Textual copies redact the local "
    "account holder's first name and email addresses. MANIFEST.csv records every "
    "local source preimage hash and every public transformed hash, so the privacy "
    "transformation is explicit and auditable. MANIFEST.csv excludes itself.\n\n"
    "The front-facing corpus reader remains the existing complete reader. This "
    "bundle is audit evidence, not a new translation, regional localization, or "
    "claim of full CJK backend report-v3 conformance.\n"
).encode("utf-8")
(STAGE / "README.md").write_bytes(readme)
rows.append(
    {
        "path": "README.md",
        "bytes": len(readme),
        "sha256": sha256(readme),
        "source": "generated",
        "source_bytes": len(readme),
        "source_sha256": sha256(readme),
        "transform": "generated",
        "name_redactions": 0,
        "email_redactions": 0,
    }
)

rows.sort(key=lambda row: str(row["path"]))
manifest_io = io.StringIO(newline="")
writer = csv.DictWriter(
    manifest_io,
    fieldnames=(
        "path",
        "bytes",
        "sha256",
        "source",
        "source_bytes",
        "source_sha256",
        "transform",
        "name_redactions",
        "email_redactions",
    ),
    lineterminator="\n",
)
writer.writeheader()
writer.writerows(rows)
manifest = manifest_io.getvalue().encode("utf-8")
(STAGE / "MANIFEST.csv").write_bytes(manifest)

text_failures: list[str] = []
secret_failures: list[str] = []
for path in sorted(STAGE.rglob("*")):
    if not path.is_file():
        continue
    data = path.read_bytes()
    rel = path.relative_to(STAGE).as_posix()
    if path.suffix.lower() in TEXT_SUFFIXES:
        if NAME_RE.search(data.decode("utf-8")):
            text_failures.append(rel)
    for label, pattern in SECRET_PATTERNS.items():
        if pattern.search(data):
            secret_failures.append(f"{rel}:{label}")
if text_failures or secret_failures:
    raise SystemExit(
        json.dumps(
            {"name_failures": text_failures, "secret_failures": secret_failures},
            ensure_ascii=False,
        )
    )

with zipfile.ZipFile(
    OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
) as archive:
    for path in sorted(STAGE.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(STAGE).as_posix()
        info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        info.create_system = 3
        archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

result = {
    "schema": "zh-noether-provenance-build-v1",
    "result": "PASS",
    "archive": OUTPUT.name,
    "archive_bytes": OUTPUT.stat().st_size,
    "archive_sha256": sha256(OUTPUT.read_bytes()),
    "members": len(rows) + 1,
    "manifest_members": len(rows),
    "manifest_bytes": len(manifest),
    "manifest_sha256": sha256(manifest),
    "public_member_bytes": sum(int(row["bytes"]) for row in rows) + len(manifest),
    "source_member_bytes": sum(int(row["source_bytes"]) for row in rows),
    "privacy_redacted_files": sum(row["transform"] == "privacy_redaction_v1" for row in rows),
    "name_redactions": total_name_redactions,
    "email_redactions": total_email_redactions,
    "name_scan_failures": text_failures,
    "secret_scan_failures": secret_failures,
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
