from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
RESERVATION = json.loads((HERE / "reserve.json").read_text(encoding="utf-8"))
DRAFT_ID = int(RESERVATION["draft_id"])
TOKEN = TOKEN_PATH.read_text(encoding="utf-8").strip()

EXPECTED = {
    "00_NOETHER_zh-Hans_COMPLETE_READER.pdf": (
        3169126,
        "0B6D9B78874325DE2C82C15FB07C6FE61DDB1A428E5F995A2F75D40961AA9079",
    ),
    "01_NOETHER_zh-Hans_SOURCE.zip": (
        69998588,
        "D790F65B07E632D7E239C429444C1458523EAAF19CB81FEF8D9245351E8B1550",
    ),
    "02_NOETHER_zh-Hans_EVIDENCE.zip": (
        1648561,
        "FE5B200E57C583710715D492072BEEC0504009732B6A3EEE2C3459CE90E22B9C",
    ),
    "03_NOETHER_zh-Hans_SHA256.txt": (
        686,
        "124F6EBBE89B1A70071C425EBBB19E9AB0CA186876C87C9FEF1B0E4FA8E31283",
    ),
    "04_NOETHER_zh-Hans_R10B_BODY.pdf": (
        3129044,
        "0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544",
    ),
    "05_NOETHER_zh-Hans_PROVENANCE.zip": (
        577746,
        "5BF76D218CAAF9D76C7986DA73CF04607A27AA86E1812F5B10FFA9E6FDD7C57A",
    ),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def request(url: str) -> bytes:
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "User-Agent": "zh-noether-provenance-release/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=240) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Zenodo HTTP {exc.code}: {body}") from None


draft_body = request(f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}")
draft = json.loads(draft_body)
files = {item["filename"]: item for item in draft.get("files", [])}
errors: list[str] = []
if set(files) != set(EXPECTED):
    errors.append(
        "set:" + json.dumps(
            {
                "missing": sorted(set(EXPECTED) - set(files)),
                "extra": sorted(set(files) - set(EXPECTED)),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
    )
rows = []
for name, (expected_bytes, expected_sha) in EXPECTED.items():
    item = files.get(name)
    if item is None:
        continue
    data = request(item["links"]["download"])
    actual_sha = sha256(data)
    if len(data) != expected_bytes:
        errors.append(f"bytes:{name}")
    if actual_sha != expected_sha:
        errors.append(f"sha256:{name}")
    rows.append(f"{name}\t{len(data)}\t{actual_sha}\n")

metadata = draft.get("metadata", {})
if metadata.get("version") != "1.0.2":
    errors.append("metadata:version")
if metadata.get("publication_date") != "2026-08-30":
    errors.append("metadata:publication_date")
if metadata.get("title") != "埃米·诺特数学著作全集——完整简体中文版 / Emmy Noether: Complete Simplified Chinese Corpus Edition":
    errors.append("metadata:title")
if metadata.get("access_right") != "open":
    errors.append("metadata:access_right")
description = str(metadata.get("description", ""))
if "Version 1.0.2 provenance successor" not in description:
    errors.append("metadata:description_note")
if "TTP" in description or "Translation and Transcription Project" in description:
    errors.append("metadata:forbidden_project_label")
if "[USER]" in description:
    errors.append("metadata:private_name")
reserved = metadata.get("prereserve_doi", {})
if reserved.get("doi") != RESERVATION["reserved_doi"]:
    errors.append("metadata:reserved_doi")

inventory = "".join(sorted(rows)).encode("utf-8")
result = {
    "schema": "zh-noether-v102-draft-verify-v1",
    "result": "PASS" if not errors else "FAIL",
    "draft_id": DRAFT_ID,
    "reserved_doi": RESERVATION["reserved_doi"],
    "files": len(files),
    "bytes": sum(item[0] for item in EXPECTED.values()),
    "inventory_sha256": sha256(inventory),
    "draft_response_sha256": sha256(draft_body),
    "errors": errors,
    "credential_material_logged": False,
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
raise SystemExit(0 if not errors else 1)
