from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXCLUDED = {"manifest.csv", "v1.json", "v2.json"}
rows = list(csv.DictReader((ROOT / "manifest.csv").open(encoding="utf-8", newline="")))
errors: list[str] = []
declared = {row["path"] for row in rows}
actual = {
    path.name
    for path in ROOT.iterdir()
    if path.is_file() and path.name not in EXCLUDED
}
if declared != actual:
    errors.append(
        "set:" + json.dumps(
            {"missing": sorted(declared - actual), "extra": sorted(actual - declared)},
            sort_keys=True,
            separators=(",", ":"),
        )
    )
for row in rows:
    path = ROOT / row["path"]
    if not path.is_file():
        continue
    data = path.read_bytes()
    if len(data) != int(row["bytes"]):
        errors.append(f"bytes:{row['path']}")
    if hashlib.sha256(data).hexdigest().upper() != row["sha256"]:
        errors.append(f"sha256:{row['path']}")
receipt = json.loads((ROOT / "receipt.json").read_text(encoding="utf-8"))
if receipt.get("result") != "PASS_PUBLISHED_PUBLICLY_REPLAYED":
    errors.append("receipt:result")
for name in ("draft1.json", "draft2.json", "public1.json", "public2.json"):
    data = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if data.get("result") != "PASS" or data.get("errors") != []:
        errors.append(f"verifier:{name}")
result = {
    "schema": "zh-noether-v102-local-verify-v1",
    "result": "PASS" if not errors else "FAIL",
    "manifest_members": len(rows),
    "manifest_member_bytes": sum(int(row["bytes"]) for row in rows),
    "manifest_sha256": hashlib.sha256((ROOT / "manifest.csv").read_bytes()).hexdigest().upper(),
    "receipt_bytes": (ROOT / "receipt.json").stat().st_size,
    "receipt_sha256": hashlib.sha256((ROOT / "receipt.json").read_bytes()).hexdigest().upper(),
    "errors": errors,
}
print(json.dumps(result, sort_keys=True, separators=(",", ":")))
raise SystemExit(0 if not errors else 1)
