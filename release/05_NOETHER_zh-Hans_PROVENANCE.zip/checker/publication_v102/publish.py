from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
TOKEN_PATH = Path(r"C:\Users\[USER]\Documents\Obsidian notes\New zenodo token.md")
RESERVATION = json.loads((HERE / "reserve.json").read_text(encoding="utf-8"))
DRAFT_ID = int(RESERVATION["draft_id"])
TOKEN = TOKEN_PATH.read_text(encoding="utf-8").strip()
req = urllib.request.Request(
    f"https://zenodo.org/api/deposit/depositions/{DRAFT_ID}/actions/publish",
    data=b"{}",
    method="POST",
    headers={
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json",
        "User-Agent": "zh-noether-provenance-release/1.0",
    },
)
try:
    with urllib.request.urlopen(req, timeout=180) as response:
        status = response.status
        body = response.read()
except urllib.error.HTTPError as exc:
    error_body = exc.read().decode("utf-8", errors="replace")
    raise SystemExit(f"Zenodo HTTP {exc.code}: {error_body}") from None
if status not in (200, 201, 202):
    raise SystemExit(f"unexpected publish status {status}")
published = json.loads(body)
result = {
    "schema": "zh-noether-v102-publish-v1",
    "result": "PASS",
    "http": status,
    "record_id": published.get("record_id") or published.get("id"),
    "doi": published.get("doi") or published.get("metadata", {}).get("doi"),
    "conceptrecid": published.get("conceptrecid"),
    "state": published.get("state"),
    "submitted": published.get("submitted"),
    "response_sha256": hashlib.sha256(body).hexdigest().upper(),
    "credential_material_logged": False,
}
encoded = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
(HERE / "publish.json").write_bytes(encoded)
print(
    json.dumps(
        {
            "result": "PASS",
            "http": status,
            "record_id": result["record_id"],
            "doi": result["doi"],
            "receipt_bytes": len(encoded),
            "receipt_sha256": hashlib.sha256(encoded).hexdigest().upper(),
        },
        sort_keys=True,
        separators=(",", ":"),
    )
)
