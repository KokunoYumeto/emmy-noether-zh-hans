from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path, PurePosixPath


HERE = Path(__file__).resolve().parent
ARCHIVE = HERE / "05_NOETHER_zh-Hans_PROVENANCE.zip"
NAME_RE = re.compile(r"(?i)[USER]")
TEXT_SUFFIXES = {".csv", ".json", ".jsonl", ".md", ".py", ".tsv", ".txt"}
SECRET_PATTERNS = {
    "github_classic": re.compile(rb"ghp_[A-Za-z0-9]{20,}"),
    "github_fine_grained": re.compile(rb"github_pat_[A-Za-z0-9_]{20,}"),
    "jwt": re.compile(rb"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
    "assigned_secret": re.compile(
        rb"(?i)(?:access[_-]?token|api[_-]?key|password|secret)\s*[:=]\s*[\"']?[A-Za-z0-9_./+-]{16,}"
    ),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


errors: list[str] = []
seen: set[str] = set()
members: dict[str, bytes] = {}
with zipfile.ZipFile(ARCHIVE, "r") as archive:
    bad_crc = archive.testzip()
    if bad_crc:
        errors.append(f"crc:{bad_crc}")
    for info in archive.infolist():
        name = info.filename
        if name.endswith("/"):
            errors.append(f"directory:{name}")
            continue
        parts = PurePosixPath(name).parts
        if not parts or name.startswith("/") or ".." in parts or "\\" in name:
            errors.append(f"unsafe:{name}")
        if name.casefold() in seen:
            errors.append(f"duplicate:{name}")
        seen.add(name.casefold())
        members[name] = archive.read(info)

if "MANIFEST.csv" not in members:
    errors.append("missing:MANIFEST.csv")
    manifest_rows: list[dict[str, str]] = []
else:
    manifest_rows = list(
        csv.DictReader(io.StringIO(members["MANIFEST.csv"].decode("utf-8"), newline=""))
    )

declared = {row["path"] for row in manifest_rows}
actual = set(members) - {"MANIFEST.csv"}
if declared != actual:
    errors.append(
        "set:" + json.dumps(
            {"missing": sorted(declared - actual), "extra": sorted(actual - declared)},
            sort_keys=True,
            separators=(",", ":"),
        )
    )
for row in manifest_rows:
    name = row["path"]
    data = members.get(name)
    if data is None:
        continue
    if len(data) != int(row["bytes"]):
        errors.append(f"bytes:{name}")
    if sha256(data) != row["sha256"]:
        errors.append(f"sha256:{name}")

for name, data in sorted(members.items()):
    if Path(name).suffix.lower() in TEXT_SUFFIXES:
        text = data.decode("utf-8")
        if NAME_RE.search(text):
            errors.append(f"name:{name}")
    for label, pattern in SECRET_PATTERNS.items():
        if pattern.search(data):
            errors.append(f"secret:{label}:{name}")

inventory = "".join(
    f"{name}\t{len(data)}\t{sha256(data)}\n" for name, data in sorted(members.items())
).encode("utf-8")
result = {
    "schema": "zh-noether-provenance-verify-v1",
    "result": "PASS" if not errors else "FAIL",
    "archive": ARCHIVE.name,
    "archive_bytes": ARCHIVE.stat().st_size,
    "archive_sha256": sha256(ARCHIVE.read_bytes()),
    "members": len(members),
    "member_bytes": sum(len(data) for data in members.values()),
    "manifest_members": len(manifest_rows),
    "inventory_sha256": sha256(inventory),
    "errors": errors,
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
raise SystemExit(0 if not errors else 1)
