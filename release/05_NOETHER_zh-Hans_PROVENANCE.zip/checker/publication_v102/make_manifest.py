from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXCLUDED = {"manifest.csv", "v1.json", "v2.json"}
paths = sorted(
    path
    for path in ROOT.iterdir()
    if path.is_file() and path.name not in EXCLUDED and path.name != "manifest.csv"
)
with (ROOT / "manifest.csv").open("w", encoding="utf-8", newline="") as handle:
    writer = csv.writer(handle, lineterminator="\n")
    writer.writerow(("path", "bytes", "sha256"))
    for path in paths:
        data = path.read_bytes()
        writer.writerow((path.name, len(data), hashlib.sha256(data).hexdigest().upper()))
