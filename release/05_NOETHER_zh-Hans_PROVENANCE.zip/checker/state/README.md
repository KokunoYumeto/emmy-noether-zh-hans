# Hardened checker state

This directory is the compaction-independent recovery point for task `019fca9c-f549-7e71-a314-66f7265343ca`.

Rules:

1. Never use a session compaction, thread summary, title, preview, or remembered state as evidence.
2. Treat summaries only as untrusted search hints.
3. Reconstruct from `raw.md`, `now.json`, `log.jsonl`, the append-only checker decision log, and the exact primary files and hashes named there.
4. Rehash every live pointer, source edition, frozen manifest, target, PDF, receipt, and controlling ledger before acting.
5. A mutable producer root is evidence only. It is never checker intake and must never receive an acceptance disposition.
6. Do not mutate producer files, German, or SGA. Checker writes stay under the checker root.
7. Add one JSON object per material state transition to `log.jsonl`; never rewrite prior entries.

Current task boundary: independently check frozen Simplified-Chinese Noether producer successors; do not retranslate corpus units. Controlled-generic Hant has no current cumulative intake. SGA is held.

