from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
from pathlib import Path

import requests


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[5]
WORKING = WORKSPACE / "03_projects" / "language_management" / "cjk" / "03_working_translations"
HEAD = WORKING / "zh_r10b"
PRODUCER = WORKSPACE / "03_projects" / "cjk_notation"
EXPECTED_ROOTS = ["zh_r10", "zh_r10b", "zh_r8", "zh_r9"]
EXPECTED_MANIFEST = "7B8F8B1A4D399EF34AF618CA7609F44A9A745FECB6CB3D346B570B4FFB479EEC"
EXPECTED_TEX = "553446A494A59530946AB70EC2F672BED4D45A33B7FA554765A11B8C038DA6D4"
EXPECTED_PDF = "0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544"
EXPECTED_MAIN = "F5345F4105F90168A50043399F49EB9E900E33F8"
EXPECTED_TAG_OBJECT = "52545BD80896E428261B39D3EF284342D8A36AB5"
EXPECTED_TAG_COMMIT = "58A2F37E8BFAAFE5D28E782A5F1B656A4DA55E5F"
EXPECTED_ZENODO_JSON = "859BA8A635F83C11AAAC5A2ED2ADF0AADB05439F5257833F07DEFEE327C541A3"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def file_id(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": sha256(data)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    errors: list[str] = []

    def check(condition: bool, label: str) -> None:
        if not condition:
            errors.append(label)

    roots = sorted(path.name for path in WORKING.glob("zh_r*") if path.is_dir())
    check(roots == EXPECTED_ROOTS, "roots:new_or_missing")

    manifest_path = HEAD / "manifest.csv"
    manifest_id = file_id(manifest_path)
    check(manifest_id["sha256"] == EXPECTED_MANIFEST, "head:manifest")
    rows = list(csv.DictReader(manifest_path.open(encoding="utf-8", newline="")))
    replay_errors: list[str] = []
    for row in rows:
        path = HEAD / row["path"]
        if not path.is_file():
            replay_errors.append(f"missing:{row['path']}")
            continue
        data = path.read_bytes()
        if len(data) != int(row["bytes"]):
            replay_errors.append(f"bytes:{row['path']}")
        if sha256(data) != row["sha256"]:
            replay_errors.append(f"sha256:{row['path']}")
    check(not replay_errors, "head:replay")
    tex_id = file_id(HEAD / "reader.tex")
    pdf_id = file_id(HEAD / "reader.pdf")
    check(tex_id["sha256"] == EXPECTED_TEX, "head:tex")
    check(pdf_id["sha256"] == EXPECTED_PDF, "head:pdf")

    session = requests.Session()
    session.headers.update({"User-Agent": "zh-noether-currentness/1.0"})
    record_response = session.get("https://zenodo.org/api/records/22172487", timeout=60)
    record_response.raise_for_status()
    record = record_response.json()
    relation_tuples = [
        (item.get("relation"), item.get("identifier"))
        for item in record["metadata"].get("related_identifiers", [])
    ]
    check(record.get("doi") == "10.5281/zenodo.22172487", "zenodo:doi")
    check(record.get("conceptdoi") == "10.5281/zenodo.21933034", "zenodo:concept")
    check(record["metadata"].get("version") == "1.0.2", "zenodo:version")
    check(
        ("isDerivedFrom", "10.5281/zenodo.21848304") in relation_tuples,
        "zenodo:source_relation",
    )
    versions_response = session.get(record["links"]["versions"], timeout=60)
    versions_response.raise_for_status()
    versions = sorted(
        str(item["metadata"]["version"])
        for item in versions_response.json()["hits"]["hits"]
    )
    check(versions == ["1.0.0", "1.0.1", "1.0.2"], "zenodo:versions")

    refs_process = subprocess.run(
        [
            "git",
            "ls-remote",
            "https://github.com/KokunoYumeto/emmy-noether-zh-hans.git",
            "refs/heads/main",
            "refs/tags/v1.0.2",
            "refs/tags/v1.0.2^{}",
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    check(refs_process.returncode == 0, "github:ls_remote")
    refs = {
        ref: commit.upper()
        for commit, ref in (
            line.split("\t", 1)
            for line in refs_process.stdout.splitlines()
            if "\t" in line
        )
    }
    public_main = refs.get("refs/heads/main", "")
    check(public_main == EXPECTED_MAIN, "github:main")
    check(refs.get("refs/tags/v1.0.2") == EXPECTED_TAG_OBJECT, "github:tag")
    check(refs.get("refs/tags/v1.0.2^{}") == EXPECTED_TAG_COMMIT, "github:tag_commit")
    raw_response = session.get(
        "https://raw.githubusercontent.com/KokunoYumeto/emmy-noether-zh-hans/"
        f"{EXPECTED_MAIN.lower()}/.zenodo.json",
        timeout=60,
    )
    raw_response.raise_for_status()
    check(sha256(raw_response.content) == EXPECTED_ZENODO_JSON, "github:zenodo_json")
    release_response = session.get(
        "https://github.com/KokunoYumeto/emmy-noether-zh-hans/releases/tag/v1.0.2",
        timeout=60,
    )
    check(release_response.status_code == 200, "github:release_page")

    producer_state = json.loads((PRODUCER / "STATE.json").read_text(encoding="utf-8"))
    check(producer_state.get("last_decision_id") == "CJK-NOT-D041", "producer:decision")

    result = {
        "schema": "zh-noether-currentness-v2",
        "receipt_id": "ZHCHK-NOETHER-CURRENTNESS-002",
        "result": "PASS_NO_NEW_TARGET" if not errors else "NEW_TARGET_OR_FAILURE",
        "immediate_cumulative_roots": roots,
        "newer_frozen_successor": roots != EXPECTED_ROOTS,
        "accepted_head": {
            "root": str(HEAD),
            "manifest": manifest_id,
            "manifest_entries": len(rows),
            "manifest_member_bytes": sum(int(row["bytes"]) for row in rows),
            "manifest_replay": f"{len(rows) - len(replay_errors)}/{len(rows)}",
            "replay_errors": replay_errors,
            "tex": tex_id,
            "pdf": pdf_id,
        },
        "publication": {
            "version_doi": record.get("doi"),
            "concept_doi": record.get("conceptdoi"),
            "version": record["metadata"].get("version"),
            "versions": versions,
            "public_files": len(record.get("files", [])),
            "public_bytes": sum(int(item["size"]) for item in record.get("files", [])),
            "source_relation": ["isDerivedFrom", "10.5281/zenodo.21848304"],
        },
        "github": {
            "main_commit": public_main,
            "tag_object": refs.get("refs/tags/v1.0.2"),
            "tag_commit": refs.get("refs/tags/v1.0.2^{}"),
            "zenodo_json_bytes": len(raw_response.content),
            "zenodo_json_sha256": sha256(raw_response.content),
            "release_page_http": release_response.status_code,
        },
        "probe_history": [
            {
                "surface": "GitHub unauthenticated REST release endpoint",
                "result": "HTTP 403 rate limit before receipt write",
                "fallback": "narrow git ls-remote, raw .zenodo.json, and public release page",
            }
        ],
        "producer": {
            "last_decision_id": producer_state.get("last_decision_id"),
            "status": producer_state.get("status"),
            "state": file_id(PRODUCER / "STATE.json"),
            "decisions": file_id(PRODUCER / "decisions.jsonl"),
        },
        "errors": errors,
    }
    encoded = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    if args.output:
        output = args.output if args.output.is_absolute() else HERE / args.output
        output.write_text(encoded, encoding="utf-8", newline="\n")
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
