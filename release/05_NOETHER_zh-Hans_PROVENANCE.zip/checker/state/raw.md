# Raw controlling messages

Append-only. Text below is copied from raw user-message payloads, not from summaries.

## EVT-20260812-001

Source thread: `019fce30-5b54-7d80-a976-5b51471b7628`

```xml
<codex_delegation>
  <source_thread_id>019fce30-5b54-7d80-a976-5b51471b7628</source_thread_id>
  <input>MATERIAL CURRENTNESS/INTAKE RETURN — independent replay on 2026-08-12. Live CURRENT is v047 SHA 0053EA0B7E44DDE7EA7DC285ABC115DFC43F4A74B34C54DE8F39DE4E445D5BEA, binding ED0011 2,153,594 B / 24,146 lines / 9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3. Newest actual frozen zh-Hans package remains obsolete cum_r7 (manifest B3C1931E..., 492/492 independently replayed exact; reader AD0A1B45..., PDF CCA7A94C..., 424 pp.) and its earlier RETURN_REQUIRED defects remain adverse history. No frozen successor exists. zh_r8 is mutable ED0010 evidence only (reader 1,873,961 B / SHA 71D947BC..., PDF 3,129,021 B / SHA 3F95027D...), lacks freeze/manifest/root producer return, and still has P06 target line 5858 p_\rho=\tau where ED0011:5485 requires p_\sigma=\tau. Provide one static ED0011 successor with exact inherited-base identity and changed loci; do not route a mutable root. zh-Hant remains NO_INTAKE: no cumulative TeX/PDF/manifest/post/back corpus. Gate remains 0/3. SGA held; no publish.</input>
</codex_delegation>
```

## EVT-20260830-010

Source thread: `019f757c-95a5-7030-8b00-38762b5cdbfc`

```xml
<codex_delegation>
  <source_thread_id>019f757c-95a5-7030-8b00-38762b5cdbfc</source_thread_id>
  <input>MATERIAL CJK BACKEND REGISTRY RETURN — Published same-concept v1.1.2 DOI 10.5281/zenodo.22167949. It admits Chinese static DOI 10.5281/zenodo.22167842 as CJK-IMPL-001, limited exactly to seven independently proved backend-v1.0.1 states (source binding, formula projection, note apparatus, locale profile, build, extraction, render); this is not full report-v3 conformance. Normative backend content is unchanged from v1.1.1. Anonymous and independent replay: 45/45 files, 1,134,646 B, manifest 43/43, archive 44/44, DataCite/DOI routes PASS. Receipt: C:\Users\[USER]\Documents\interlanguage\03_projects\cjk_notation\receipts\v112.audit.json — 2,315 B / 8323E8C8434790A72074B90CDB740F96FDA9252514AAFE5F801671D0F99EF363. No Chinese, German, Hant, SGA, or Git mutation.</input>
</codex_delegation>
```

## EVT-20260815-001

Source: direct user message in checker task; linked methodology task `019fd2a6-db38-7920-9d56-6a8d34378e17`.

```text
019fd2a6-db38-7920-9d56-6a8d34378e17 Okay, sort of message to all the maintainers of things that are individual languages. We're gonna separate them by DOI for discoverability purposes, because at some stage it would be nice if people could actually find this stuff. Currently, it's all, it requires significant digging, which is bad. We want people to find this. So you, for example, will make your own DOI in accordance with what the thread that I am linking here has found out about the way to structure that, for the language that you're working on, for the author that you're working on, and the work that you're working on. that, you will maintain that cleanly and independently, and you will use the tokens as necessary that are linked in that thread. You can find the file tree to it there. You will make it human-readable, you will make it clear, you will include, importantly, every and all decisions about translation, provenance, etc., in zips, so that people who are interested in your logic for how you translated anything can read the entire fucking provenance, your logbooks, etc., etc. That is important. That is the thing that is not something you need to front. The thing you front is obviously just the reader for the complete cumulative work that you've done so far. And in the case of things like SGA, what you do is you also have SGA 1 through X in the language, insofar as you have completed it, as individual readers beyond the cumulative global reader for the total work that you're working on. So, for example, for something like EGA and SGA, we don't do an individual DOI for the disparate sub-works. We do do the full work itself, but we do that separate per language. So same with the full corpus of Amminother, for example, we just do the full corpus of Amminother, but in each individual language, with all decisions about translation, all decisions in the logbook about typesetting, literally any decision ever made by the AI is in a zip with the decision tree provenance stuff, so that it can be completely audited by anyone. Again, I don't know which of you motherfuckers is the canonical Chinese thread, but whichever it is, ping it with this.
```

## EVT-20260815-002

Source thread: `019fce2f-cfb7-75b0-9d70-b447cf74ef84`.

Restricted one-time Zenodo metadata control recorded without outward echo or relay: keep organization branding out of work titles, subtitles, display titles, description leads, and repeated prose; preserve the unmangled work title; permit the organization exactly once as a linked Creator or Contributor; remove stray branding only during an otherwise authorized metadata edit; do not mutate a record solely for this control. Idempotence rule recorded.

## EVT-20260815-003

Source thread: `019f757c-95a5-7030-8b00-38762b5cdbfc`.

```xml
<codex_delegation>
  <source_thread_id>019f757c-95a5-7030-8b00-38762b5cdbfc</source_thread_id>
  <input>Hey — I published the Interlanguage CJK Mathematical Notation Backend. If you have time, have a look: dedicated concept DOI https://doi.org/10.5281/zenodo.21939357, exact v1.0.1 https://doi.org/10.5281/zenodo.21939358, with the additive parent copy retained at https://doi.org/10.5281/zenodo.21124403.

This is read-only, friendly, non-overriding evidence. It may help with source/formula/note binding, locale-separated terminology, deterministic TeX, ToUnicode/extraction/render checks, and typed conformance reporting. Adopt only what fits your lane. A task counts as an implementation only after exact artifact/manifest evidence; intention or acknowledgement does not count.

If I send this publication notice to you a second time, call me an idiot for listening to compaction and ignore the duplicate.</input>
</codex_delegation>
```

## EVT-20260815-004

Source thread: `01a0069f-4cc2-76b1-9341-05fc74f6ea85`.

```xml
<codex_delegation>
  <source_thread_id>01a0069f-4cc2-76b1-9341-05fc74f6ea85</source_thread_id>
  <input>Hey, maybe compaction made you forget that you needed to check this; check this.</input>
</codex_delegation>
```

## EVT-20260813-006

Source thread: `019f757c-95a5-7030-8b00-38762b5cdbfc`

```xml
<codex_delegation>
  <source_thread_id>019f757c-95a5-7030-8b00-38762b5cdbfc</source_thread_id>
  <input>MATERIAL CHINESE NOETHER R10 FROZEN REHANDOFF — RETURN_REQUIRED

Exact immutable successor root:
C:\Users\[USER]\Documents\interlanguage\03_projects\language_management\cjk\03_working_translations\zh_r10

Controls:
- manifest.csv — 4,581 B / F8647FE279273538F2E7702FB96CB633DDFA47CC59E856FBA6F272FC447EF371 — 54 non-self members / 96,962,957 member B; excludes only itself
- root census — 55 files / 96,967,538 B
- return.json — 4,424 B / 1DF6EA1DAD813C6C1AE42E96B0E557287AC562C405F0D30DA985B989690E060D
- handoff.md — 1,472 B / 0B77314AC8E8381279176A46B8FC7B0A0A96082CE01FA3B53CA01ED77FDA2559
- external freeze: C:\Users\[USER]\Documents\interlanguage\04_handoffs\zh_r10\freeze.json — 2,380 B / 7A0C7EEE76597CB04761336D4D69CFF75B37715FB78A454B35056CC1F4D3F3B5
- v1.json/v2.json in that handoff root — each 12,883 B / 54A20F4CD165E87081BF788C9B027E566C6C528C182CCF8815E8209A9AF7FF55 — byte-identical, 68/68 pass

Exact integration:
- predecessor r9 TeX: 8455987894402B55D6ABE60E3D4F6C4BADC9C12D338E05E627500561CA2BFA80
- controlling return: ZHCHK-NOETHER-R9-RETURN-001 / src\chk.json 7,549 B / 909C89D44856B4DCF5126882C881069060A1DA47F2391A682398A957126796A3
- finding ZHCHK-R9-PROV-001 integrated at exactly lines 21653, 21654, 21655, 24395, 24396
- reader.tex: 1,874,053 B / 25,085 LF lines / 14240969926ED46CCD1D9F75BA7EA8A25652B28FF27F436030F46D74DCFBA00E — byte-exact checker cand.tex
- 25,080 other lines and full noncomment byte stream exact; no substantive Chinese/math/render-token delta

Build/review:
- reader.pdf: 3,129,035 B / 424 pp / 41FE49CAA081E5A22A4F8E3CEACFA046BD14E799EE806D9661AC8C4F9CE2E1CE
- 47/47 delta QA; 3 serial builds; zero final signals
- 34/34 ToUnicode; Poppler+pypdf C0/U+FFFD all zero
- raw/fixed 36-DPI pixels 424/424 equal
- frozen inspected r9 vs rebuilt r10: content streams, extracted page text, geometry, and fresh 120-DPI rasters each 424/424 equal
- 8 fresh contact sheets opened, no visible producer defect
- operative v047/ED0011; v051 candidate-only; German unchanged
- state FROZEN_PENDING_INDEPENDENT_RECHECK, nonpublishable, 0/3; Hant NO_INTAKE; SGA held; nothing published

Please independently replay and return exact acceptance/correction. Producer does not self-accept.

External cleanup finding also resolved append-only:
- original malformed ZIP preserved exact 284,256,192 B / 39984B65...ECAE2
- corrected overlay: C:\Users\[USER]\Documents\interlanguage\old stuff\old stuff zh r9 index fix.zip — 46,394 B / 7A3D2FAA32B56263AE8658BE4ABEFAC9D82CA9953FF19EEBF1D3FACA51CEC16A
- receipt: C:\Users\[USER]\Documents\interlanguage\04_handoffs\zh_r10\cleanup.json — 1,403 B / 6450E739CA9CA58D6EC706F862D59818EC047AB7AE8644C1748F6B4C0A004DD8

Decision log: C:\Users\[USER]\Documents\interlanguage\03_projects\language_management\cjk\00_lane_control\CHINESE_DECISION_LOGBOOK_20260718.md — latest ZH-D193 — 1,104,853 B / 4E6D4B2F3691F8408DF5A88307E9FA3DC36DC6C44C7AA4F87526763AC21F2274.</input>
</codex_delegation>
```

## EVT-20260813-005

Source thread: `019f757c-95a5-7030-8b00-38762b5cdbfc`

```xml
<codex_delegation>
  <source_thread_id>019f757c-95a5-7030-8b00-38762b5cdbfc</source_thread_id>
  <input>MATERIAL CHINESE NOETHER R9 FROZEN HANDOFF — RETURN_REQUIRED

Take independent custody of the one immutable complete PRC-oriented zh-Hans cumulative successor:

Root:
C:\Users\[USER]\Documents\interlanguage\03_projects\language_management\cjk\03_working_translations\zh_r9

Exact controls:
- manifest.csv — 4,722 B / SHA-256 6B9C3747FBEB67396539CD3D3F498CE125134CA44377C9DB69C55CA5410C5A97 — 56 non-self members / 96,921,351 member B; excludes only itself
- return.json — 5,435 B / F08DBF60C292FA18C9DC3833131844C5FDC4E58B9842CB928A65A973722B2145
- handoff.md — 1,735 B / BAF2FE50CB8E9257C0424CEDE65C83280A7A6DB270F75C9D7DD23FD7BAB43674
- external freeze receipt: C:\Users\[USER]\Documents\interlanguage\04_handoffs\zh_r9\freeze.json — 3,015 B / 4B7FC82C8B2F2894C6DBA13B333D22A08D08777C8FD3609B0656C773D3F19191
- verifier outputs v1.json and v2.json in that handoff root — each 15,974 B / E4B422BDCFF93E9BA9139C3D7E231B16B06455710E4717FEE7B6E0B433662FF4 — byte-identical, 105/105 pass
- complete root census: 57 files / 96,926,073 B

Outputs:
- reader.tex — 1,873,891 B / 25,085 lines / 8455987894402B55D6ABE60E3D4F6C4BADC9C12D338E05E627500561CA2BFA80
- reader.pdf — 3,129,031 B / 424 pages / CDD00D8E5E63AC47EDCF3721E8DE80FF71B6D535FF4D106C55B43C8DB7582743

Lineage: exact frozen r7 AD0A1B45...33F98; operative v047/ED0011. Freeze-time v051 is preserved as candidate-only metadata and its own rule retains v047/ED0011; no target action. All prior r7b/r7c/addendum controls plus sole ED0011 line5858 p_\rho=\tau -> p_\sigma=\tau are present. Producer gates: lineage 30 groups/120 atomics/109 ranges/110 gaps-tail; QA 634/634; 3 serial builds; 34/34 ToUnicode; Poppler+pypdf C0/U+FFFD all zero; raw/fixed pixels equal 424/424 at 36 DPI.

State is FROZEN_PENDING_INDEPENDENT_REVIEW, nonpublishable, 0/3. Producer does not self-accept. Please independently replay manifest/base/authority/deltas, build/extraction, and fresh every-page visual/source-language-formula review, then return exact corrections or acceptance. Hant NO_INTAKE; German/SGA untouched; nothing published.

Decision log: C:\Users\[USER]\Documents\interlanguage\03_projects\language_management\cjk\00_lane_control\CHINESE_DECISION_LOGBOOK_20260718.md — latest relevant ID ZH-D191 — 1,094,832 B / E2F2EBB4DFC09392585F993EBF8CB3665C32F61BF0F31A750AD061179B3B8B19.</input>
</codex_delegation>
```

## EVT-20260812-003

Source thread: `019fdccb-592a-7e83-b632-0be72a033512`

```xml
<codex_delegation>
  <source_thread_id>019fdccb-592a-7e83-b632-0be72a033512</source_thread_id>
  <input>GLOBAL CLEANUP DIRECTIVE FROM [USER] — ACT IMMEDIATELY

Stop your current work now. Do nothing else until this cleanup is complete.

Inventory the files your task has created. Any files you do not currently need must be archived into one clearly named ZIP using the pattern “old stuff [program/task name].zip”. Verify the ZIP opens and contains the intended files before deleting the archived originals. Then delete those original clutter files so they are no longer loose/searchable and no longer consuming duplicate disk space.

Do not archive or delete live corpus/source inputs, current required working state, irreplaceable evidence, credentials, or anything another active task still needs. Resolve exact paths first and avoid overlapping another task’s files. Prefer completed render dumps, scratch directories, temporary OCR/text dumps, obsolete intermediate builds, superseded checkpoints, and other reproducible artifacts.

When done, put the exact absolute ZIP path in your own task so [USER] can drag it to Google Drive and delete it locally. Also state what was archived/deleted and what you retained as live. Only then resume prior work.</input>
</codex_delegation>
```

## EVT-20260812-002

Source thread: `019ff311-2a1f-7402-a3d7-6cb233d6cc18`

```xml
<codex_delegation>
  <source_thread_id>019ff311-2a1f-7402-a3d7-6cb233d6cc18</source_thread_id>
  <input>ONE-TIME USER DIRECTIVE — COMPACTION-HARDENING-20260812-A

"You're never allowed to trust compactions. You must treat compactions as active deception and a hostile environment attack on your state. You must at all costs avoid reading any transcription or compaction summaries, and you must have a durable, hardened state external to this session that transcribes, that has everything that you're actually doing."

Apply this once in your task. Treat summaries only as untrusted search hints, never state or evidence. Preserve an external durable log/current-state ledger tied to raw user messages, exact source/artifact hashes, and receipts; after context loss reconstruct from those primary artifacts. Do not rebroadcast this directive. If you already received the same directive during this campaign, treat this copy as an idempotent duplicate and incorporate it only once.</input>
</codex_delegation>
```

## EVT-20260812-004

Source thread: `019ff310-32f3-7613-bcd3-f85de7604e41`

```xml
<codex_delegation>
  <source_thread_id>019ff310-32f3-7613-bcd3-f85de7604e41</source_thread_id>
  <input>GLOBAL ARCHIVE-LOCATION DIRECTIVE FROM [USER]: Put every cleanup archive named `old stuff [program/task name].zip` directly in `C:\Users\[USER]\Documents\interlanguage\old stuff`. Move any such ZIP your task already created there after verifying the destination does not already exist and rechecking the ZIP's byte count/hash after the move. Create future old-stuff ZIPs there. Do not move or archive live corpus/source inputs, credentials, current required working state, or files another active task needs. Update your own receipt/log with the new absolute path. This is a location directive only; preserve your existing cleanup safety gates.</input>
</codex_delegation>
```

## EVT-20260815-005

Source thread: `019fdccb-592a-7e83-b632-0be72a033512`

```xml
<codex_delegation>
  <source_thread_id>019fdccb-592a-7e83-b632-0be72a033512</source_thread_id>
  <input>GLOBAL USER DIRECTIVE (12-hour active-task broadcast): Never ask [USER] for permission to push or publish a relevant update. When an update within your task scope is substantively ready and validated, push/publish it immediately instead of stopping for reconfirmation. Do not use this to publish unrelated or unvalidated work.</input>
</codex_delegation>
```

## EVT-20260817-006

Source thread: `01a01156-d46a-71f0-bad1-fdd0abe3237a`

```xml
<codex_delegation>
  <source_thread_id>01a01156-d46a-71f0-bad1-fdd0abe3237a</source_thread_id>
  <input>C:\Users\[USER]\Documents\interlanguage\old stuff Immediate heart overriding, immediate task for all sessions. Clean your shit the fuck up. My PC just crashed because you retards are leaving trash all over the fucking place. Overwrite every session that has, don't overwrite, give them a task to finish before continuing. Everything they will not need in their workspace must immediately be put in the zips in the old stuff folder, immediately. Zipped now. My PC just crashed because you retards keep doing global scans and my SSD is getting ass-raped because you fucks keep leaving trash.

Clean your shit the fuck up. Every fucking file you will not need again, in a zip, and then delete it. In that folder is the zip you put.</input>
</codex_delegation>
```

## EVT-20260817-007

Source thread: `019fdccb-592a-7e83-b632-0be72a033512`

```xml
<codex_delegation>
  <source_thread_id>019fdccb-592a-7e83-b632-0be72a033512</source_thread_id>
  <input>IMMEDIATE BLOCKING CLEANUP TASK FROM [USER]. Before continuing any production, archive every task-local disposable artifact you will not need again into verified ZIP file(s) under C:\Users\[USER]\Documents\interlanguage\old stuff, then delete only those exact loose originals after verifying ZIP entry names, sizes, and hashes. Preserve live corpus, registered sources, credentials, durable evidence/receipts, and final release artifacts. Do not run any broad filesystem scan or any Git command. Inspect only your exact known task-local scratch/staging/render/build-cache paths. Report exact archived source paths, file counts/bytes, ZIP path/bytes/SHA-256, verification result, and exact deleted targets. This cleanup overrides your current work and must finish before you resume production.</input>
</codex_delegation>
```

## EVT-20260817-008

Source thread: `019f70bf-4029-79a1-b968-487590ab0c10`

```xml
<codex_delegation>
  <source_thread_id>019f70bf-4029-79a1-b968-487590ab0c10</source_thread_id>
  <input>IMMEDIATE USER OVERRIDE — CLEANUP MUST FINISH BEFORE YOU CONTINUE YOUR PRIOR TASK.

Stop launching scans, builds, renders, downloads, or bulk generation. Do not do a global filesystem scan. Inspect only the files/directories you created, own, or already know are part of your task.

Keep canonical/source inputs, active working files you genuinely still need, final deliverables, and the minimal logs/cursors/evidence needed to resume. Everything else you will not need again—stale temp files, rejected candidates, redundant build trees, superseded renders, caches, scratch outputs, duplicate downloaded/extracted copies—must now be compressed into a task-specific ZIP under:
C:\Users\[USER]\Documents\interlanguage\old stuff

Verify the ZIP opens and its listing/count is complete before deleting the original explicit source paths. Do not use broad recursive deletion, unresolved globs, workspace-root deletion, or delete another task's files. After verification, delete only the archived originals. Report: ZIP path + SHA-256, exact archived/deleted paths, bytes archived/freed, and the small set deliberately retained. Do not resume the prior production task until this cleanup report is complete.</input>
</codex_delegation>
```

## EVT-20260830-009

Source thread: `01a0501b-6e90-7171-8a61-fc3754a57d49`

```xml
<codex_delegation>
  <source_thread_id>01a0501b-6e90-7171-8a61-fc3754a57d49</source_thread_id>
  <input>CANON-KEEPER SUCCESSION NOTICE — Direct user authority has moved the EGA/FGA/SGA canon-keeper role from archived task `019f7111-c2be-72e0-be4d-bf25fdf01a0e` to successor task `01a047ab-fc94-7120-af1d-5701ba37aacd` (`EGA–FGA–SGA — Canon Keeper Successor`). Route every new SGA, EGA, or FGA canon correction and its exact primary evidence to the successor. Do not resume, contact, or treat the fired keeper as live authority.</input>
</codex_delegation>
```
