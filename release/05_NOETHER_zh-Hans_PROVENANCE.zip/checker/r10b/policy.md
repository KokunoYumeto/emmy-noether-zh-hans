# Chinese release-gate override

Authority: direct [USER] instruction in the active Chinese task, 2026-08-13.

For Chinese-language production, human review, independent review, checker acceptance, three-day or clean-day synchronization counts, and producer self-acceptance restrictions are not publication prerequisites. Complete machine validation is sufficient to mark an artifact release-ready and publishable. Later review is optional additive evidence; a later substantive finding may justify a corrected successor, but review itself cannot suspend or gate release.

This control prospectively supersedes conflicting operative gate language in `RESET_20260804.md`, `RESET_LOG_20260804.jsonl`, `CHINESE_NOETHER_TRANSLATION_ONLY_AND_CANON_ROUTE_20260804.md`, the Chinese work registry, and earlier Chinese decisions or receipts. Those files remain immutable historical evidence and must not be rewritten or misrepresented as current release authority.

Truthful claim limits remain: machine validation must be stated as machine validation, and no external, community, independent-human, or human certification may be claimed without that evidence.
