from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path, PurePosixPath

from pypdf import PdfReader


RET = Path(__file__).resolve().parent
PROD = Path(
    r"C:\Users\[USER]\Documents\interlanguage\03_projects\language_management\cjk\03_working_translations\zh_r10b"
)
PREV = PROD.parent / "zh_r10" / "reader.tex"
POLICY = Path(
    r"C:\Users\[USER]\Documents\interlanguage\03_projects\language_management\cjk\00_lane_control\RELEASE_GATE_OVERRIDE_20260813.md"
)
EXCLUDED = {"manifest.csv", "v1.json", "v2.json"}
PROD_PINS = {
    "manifest.csv": (4_912, "7B8F8B1A4D399EF34AF618CA7609F44A9A745FECB6CB3D346B570B4FFB479EEC"),
    "reader.tex": (1_874_083, "553446A494A59530946AB70EC2F672BED4D45A33B7FA554765A11B8C038DA6D4"),
    "reader.pdf": (3_129_044, "0C457AB0C5F31BE1F6C8B5A4EC7ACB657ABE67979D5E9339BA493B599BC2D544"),
    "STATE.md": (2_368, "B0FC9A8DA681863FAE6F1AF01FACE4F7DB7EC5518AA468356C350640D929BCAC"),
    "visual.json": (2_545, "AAD726DFC00399B1079DAC5ACD1F54DE0A4BC5FD2B2DDC62B45B13E4273F0F85"),
    "return.json": (4_853, "3BE177A771301A02EDD2CF05FDAEC190D55867B50EA963D6152570D49AC17BB6"),
}


def digest(path: Path) -> tuple[int, str]:
    value = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            size += len(chunk)
            value.update(chunk)
    return size, value.hexdigest().upper()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def safe(name: str) -> bool:
    if not name or "\\" in name:
        return False
    path = PurePosixPath(name)
    return not path.is_absolute() and all(part not in {"", ".", ".."} and ":" not in part for part in path.parts)


def load(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Verifier for the sealed R10b Chinese checker return")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    checks: list[dict[str, object]] = []

    def check(identifier: str, passed: bool, evidence: object = None) -> None:
        row: dict[str, object] = {"id": identifier, "pass": bool(passed)}
        if evidence is not None:
            row["evidence"] = evidence
        checks.append(row)

    manifest_path = RET / "manifest.csv"
    rows: list[tuple[str, int, str]] = []
    check("return_manifest_exists", manifest_path.is_file())
    if manifest_path.is_file():
        with manifest_path.open("r", encoding="utf-8", newline="") as stream:
            reader = csv.reader(stream)
            check("return_manifest_header", next(reader, None) == ["path", "bytes", "sha256"])
            for row in reader:
                if len(row) == 3:
                    rows.append((row[0], int(row[1]), row[2].upper()))
    names = [row[0] for row in rows]
    check("return_manifest_nonempty", bool(rows))
    check("return_manifest_sorted", names == sorted(names))
    check("return_manifest_safe", all(safe(name) for name in names))
    check("return_manifest_unique", len(names) == len(set(names)) == len({name.casefold() for name in names}))
    check("return_manifest_exclusions", not (set(names) & EXCLUDED))
    actual = sorted(
        path.relative_to(RET).as_posix()
        for path in RET.rglob("*")
        if path.is_file() and path.relative_to(RET).as_posix() not in EXCLUDED
    )
    check("return_member_set", actual == names, {"actual": len(actual), "listed": len(names)})
    return_failures = [
        name
        for name, size, value in rows
        if not (RET / PurePosixPath(name)).is_file() or digest(RET / PurePosixPath(name)) != (size, value)
    ]
    check("return_manifest_replay", not return_failures, return_failures)
    check("return_no_symlinks", not [str(path) for path in RET.rglob("*") if path.is_symlink()])

    producer_pin_failures = []
    for relative, expected in PROD_PINS.items():
        path = PROD / relative
        if not path.is_file() or digest(path) != expected:
            producer_pin_failures.append(relative)
    check("producer_pins", not producer_pin_failures, producer_pin_failures)
    check("policy_pin", POLICY.is_file() and digest(POLICY) == (1_152, "8B07A31E2BE62859F3593488EB664743A02D5D7F218E371529CBE6CB0BB7C0A9"))

    producer_rows: list[tuple[str, int, str]] = []
    with (PROD / "manifest.csv").open("r", encoding="utf-8", newline="") as stream:
        reader = csv.reader(stream)
        check("producer_manifest_header", next(reader, None) == ["path", "bytes", "sha256"])
        for row in reader:
            producer_rows.append((row[0], int(row[1]), row[2].upper()))
    producer_names = [row[0] for row in producer_rows]
    producer_actual = sorted(
        path.relative_to(PROD).as_posix()
        for path in PROD.rglob("*")
        if path.is_file() and path.name != "manifest.csv"
    )
    check("producer_manifest_count", len(producer_rows) == 58)
    check("producer_manifest_set", producer_actual == producer_names)
    producer_failures = [
        name
        for name, size, value in producer_rows
        if not (PROD / PurePosixPath(name)).is_file() or digest(PROD / PurePosixPath(name)) != (size, value)
    ]
    check("producer_manifest_replay", not producer_failures, producer_failures)
    check("producer_no_symlinks", not [str(path) for path in PROD.rglob("*") if path.is_symlink()])

    receipt = load(RET / "receipt.json")
    report = load(RET / "report.json")
    cleanup = load(RET / "cleanup.json")
    render = load(RET / "render.json")
    visual = load(PROD / "visual.json")
    check("return_id", receipt.get("return_id") == "ZHCHK-NOETHER-R10B-RETURN-001")
    check("accepted_publishable", receipt["disposition"]["target"] == "ACCEPTED" and receipt["disposition"]["publishable"] is True)
    check("publish_now", receipt["disposition"]["publication_action"] == "PUBLISH_IMMEDIATELY_WITHOUT_RECONFIRMATION")
    check("report_release", report["release"]["target_disposition"] == "ACCEPTED" and report["release"]["publishable"] is True)
    check("report_states", all(value["status"] == "pass" for value in report["states"].values()))
    check("backend_report_pin", digest(RET / "report.json") == (receipt["backend_crosswalk"]["bytes"], receipt["backend_crosswalk"]["sha256"]))
    check("cleanup_pin", digest(RET / "cleanup.json") == (receipt["cleanup"]["bytes"], receipt["cleanup"]["sha256"]))
    check("cleanup_verified", cleanup["verification"]["all_pass"] is True)

    evidence_failures = []
    for item in report["evidence"]:
        path = RET / item["artifact"]
        if not path.is_file() or digest(path) != (item["bytes"], item["sha256"]):
            evidence_failures.append(item["id"])
    check("report_evidence_pins", not evidence_failures, evidence_failures)

    current = (PROD / "reader.tex").read_bytes()
    previous = PREV.read_bytes()
    marker = b"\\begin{document}"
    body = current[current.index(marker) :]
    previous_body = previous[previous.index(marker) :]
    check("document_body_identity", len(body) == 1_860_638 and sha(body) == "E943EA3BE96DB436AE55B54A9075004AE83FC29D01B4DB95829B356129728D7A")
    check("document_body_equal_predecessor", body == previous_body)
    changed = [index for index, pair in enumerate(zip(previous.splitlines(keepends=True), current.splitlines(keepends=True)), 1) if pair[0] != pair[1]]
    check("exact_changed_lines", changed == [2, 5, 25], changed)

    pdf = PdfReader(str(PROD / "reader.pdf"), strict=True)
    metadata = pdf.metadata or {}
    check("pdf_pages", len(pdf.pages) == 424)
    check("pdf_title", metadata.get("/Title") == "Noether Simplified Chinese cumulative rebase r10")
    check("pdf_author", metadata.get("/Author") == "Emmy Noether")
    pdf_evidence = load(RET / "pdf.json")
    check("pdf_evidence_all_pass", pdf_evidence["all_pass"] is True)
    check("pdf_evidence_424", all(pdf_evidence[key] == 424 for key in ["content_streams_equal", "pypdf_text_equal", "geometry_equal", "annotation_counts_equal"]))
    check("dual_extraction_zero", all(pdf_evidence[engine][side][key] == 0 for engine in ["pypdf", "poppler"] for side in ["producer", "fresh"] for key in ["disallowed_internal_c0", "replacement_characters"]))
    check("fonts_34_34", all(pdf_evidence["font_tables"][side]["fonts"] == pdf_evidence["font_tables"][side]["to_unicode_yes"] == 34 for side in ["producer", "fresh"]))

    visual_finding = next(item for item in receipt["findings"] if item["id"] == "ZHCHK-R10B-VIS-001")
    recorded = {item["page"]: item for item in visual["inspection"]["latest_representative_pngs"]}
    rendered = {item["page"]: item for item in render["page_records"]}
    visual_failures = []
    for item in visual_finding["corrections"]:
        page = item["page"]
        if recorded[page]["sha256"] != item["recorded_sha256"] or rendered[page]["sha256"] != item["actual_sha256"] or rendered[page]["bytes"] != item["bytes"]:
            visual_failures.append(page)
    check("visual_hash_correction_exact", not visual_failures, visual_failures)
    check("render_pass", render["page_count"] == 424 and render["contact_sheet_count"] == 8 and render["visual_disposition"].startswith("PASS_424_OF_424"))

    state_finding = next(item for item in receipt["findings"] if item["id"] == "ZHCHK-R10B-STATE-001")
    state_line = (PROD / "STATE.md").read_bytes().splitlines(keepends=True)[14]
    correction_line = (state_finding["correction"]["text"] + "\n").encode("utf-8")
    check("state_preimage", (len(state_line), sha(state_line)) == (state_finding["preimage"]["lf_bytes"], state_finding["preimage"]["sha256"]))
    check("state_correction", (len(correction_line), sha(correction_line)) == (state_finding["correction"]["lf_bytes"], state_finding["correction"]["sha256"]))
    check("findings_nonblocking", all(item["publication_blocking"] is False and item["required_before_publication"] is False for item in receipt["findings"]))
    check("scope_boundary", receipt["scope_boundary"] == {"Hant": "NO_INTAKE", "German": "unchanged; no finding packet", "SGA": "held and untouched", "producer_root_mutated": False, "publication_performed_by_checker": False})

    all_pass = all(row["pass"] for row in checks)
    result = {
        "record_id": "ZHCHK-NOETHER-R10B-VERIFY-001",
        "return_id": "ZHCHK-NOETHER-R10B-RETURN-001",
        "checks": checks,
        "check_count": len(checks),
        "pass_count": sum(row["pass"] for row in checks),
        "failure_count": sum(not row["pass"] for row in checks),
        "all_pass": all_pass,
        "disposition": "ACCEPTED_WITH_NONBLOCKING_PROVENANCE_CORRECTIONS" if all_pass else "FAIL",
        "publishable": all_pass,
    }
    payload = (json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    if args.out:
        out = args.out.resolve()
        if out.parent != RET or out.name not in {"v1.json", "v2.json"} or out.exists():
            raise SystemExit("--out must be a new v1.json or v2.json in the return root")
        out.write_bytes(payload)
    else:
        sys.stdout.buffer.write(payload)
    if not all_pass:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
