# 埃米·诺特数学著作集 — 简体中文版

收录编号论文1–43、由M. Deuring记录的1929/30年讲义、Kapferer与Noether的论文及补篇、书目和卷末目录。

保持解压后的目录结构，在各主文件所在目录用XeLaTeX编译两次。所需宏包和字体见导言区。

- `source/reader.tex`

[作者、来源与权利](RIGHTS.md).
