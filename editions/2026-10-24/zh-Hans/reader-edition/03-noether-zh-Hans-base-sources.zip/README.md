# 埃米·诺特数学著作集：简体中文版

收录第1—43篇论文、M. Deuring记录的1929/30年冬季学期讲义、H. Kapferer论文及与E. Noether合作的补充、书目和相关著作目录。采用面向中国大陆读者的简体中文。正文中的署名、原刊信息与文献引用予以保留。

[完整可编辑LaTeX正文](source/02-noether-zh-Hans.tex)含本版全部正文，无需另行拼接篇章。`source/reader.tex`与其内容相同；`source/cover.tex`是正文中已内嵌的版本说明。订正版另附相应编者注。PDF书签可导航至全部43篇编号论文及后续部分。

## 排版

使用XeLaTeX。须安装Noto Serif、Noto Sans与Noto Sans Mono系统字体，以及源文件导言区所列的fontspec、xeCJK、AMS、TikZ、hyperref等TeX包。中文字体和等宽字体的指定文件位于`source/fonts/`，随完整源文件包提供。

解压后进入`source`目录运行以下命令；重复运行至书签和引用稳定。

```sh
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error 02-noether-zh-Hans.tex
```

直接下载的LaTeX文件也须与源文件包中的`fonts`目录放在同一目录。字体依赖不属于数学正文，完整正文已在该单一LaTeX文件中。

中文正文由AI翻译。早期制作方为Manuscript Typesetting Project / OpenAI Codex（准确模型未能确定）；本版由AI制作的订正与排版：OpenAI Codex——GPT-6 Astra，Ultra推理强度。

[作者、出处与权利](RIGHTS.md) · [早期权利声明](NOTICE_HISTORIQUE.md)

`python build.py`运行XeLaTeX两次，并采用与所附PDF相同的固定排版时刻设置；PDF内部排版日期不是出版日期。使用的引擎为XeTeX3.141592653-2.6-0.999998（MiKTeX26.5）。直接下载的LaTeX与ZIP内`source/02-noether-zh-Hans.tex`为同一文件。
