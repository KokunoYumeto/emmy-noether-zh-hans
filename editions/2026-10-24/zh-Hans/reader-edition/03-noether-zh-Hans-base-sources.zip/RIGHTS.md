# 作者、出处与权利

原作者为Emmy Noether及各篇署名的共同作者。1929/30年冬季学期讲义由M. Deuring记录；H. Kapferer的论文与E. Noether合写的补充分别保留其署名。原刊信息和文献引用见正文。

中文正文由AI翻译。早期简体中文版的制作方为Manuscript Typesetting Project / OpenAI Codex；现存出处资料不足以确定其准确模型。本版由AI制作的订正与排版：OpenAI Codex——GPT-6 Astra，Ultra推理强度。这不表示出版者亲自翻译，亦不表示经过独立学术审阅。

本版继承[简体中文版v1.0.0（2026-08-14）](https://doi.org/10.5281/zenodo.21933035)的正文；其德文底本为ED0011/v047（2026-08-08）。其中第1篇至第19篇第6节的早期中文文本见[2026-06-12法文与简体中文汇编](https://doi.org/10.5281/zenodo.20836874)。后续历史记录包括[v1.0.2](https://doi.org/10.5281/zenodo.22172487)及[v1.0.3](https://doi.org/10.5281/zenodo.22177336)。[简体中文系列标识](https://doi.org/10.5281/zenodo.21933034)与[多语种汇编](https://doi.org/10.5281/zenodo.20412587)分别指向相应资料。这些历史标识不是当前GitHub版的新DOI。

原著及受保护的衍生贡献，其权利均归各自权利人所有。本版免费提供，仅供非商业、纯教育用途；出版者推定权利人不会反对。这是推定，并非已获证实的许可；免费可读本身并不授权衍生出版。

权利人可通过[GitHub issue](https://github.com/KokunoYumeto/emmy-noether-zh-hans/issues/new)提出异议；出版者承诺依权利人的请求撤下相关材料。本版不作新的整体许可或公有领域奉献。[早期权利声明](NOTICE_HISTORIQUE.md)按原文保留，其效力限于实际授权的权利与贡献。

所附Noto字体适用SIL Open Font License 1.1。各字体文件内的版权、设计者、商标与许可信息见[字体署名](source/fonts/ATTRIBUTION.md)，[所附许可证原文](source/fonts/OFL.txt)亦予保留。TeX软件和未随包分发的系统字体适用其各自条件。
