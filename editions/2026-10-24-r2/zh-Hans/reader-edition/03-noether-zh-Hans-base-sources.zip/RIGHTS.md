# 作者、出处与权利

原作者为Emmy Noether及各篇署名的共同作者。1929/30年冬季学期讲义由M. Deuring记录；H. Kapferer的论文与E. Noether合写的补充分别保留其署名。原刊信息和文献引用见正文。

中文正文由AI翻译。早期简体中文版的制作方为Manuscript Typesetting Project / OpenAI Codex；主要由GPT-5.6 Sol（OpenAI Codex，推理强度ultra）完成。本版由AI制作的订正与排版：OpenAI Codex——GPT-6 Astra，Ultra推理强度；Claude Opus 5.5（Anthropic，max推理强度），2026-10-26至2026-10-27（公式已与依Noether印刷页面读出的德文本文核对）。这不表示出版者亲自翻译，亦不表示经过独立学术审阅。

本版继承[简体中文版v1.0.0（2026-08-14）](https://github.com/KokunoYumeto/emmy-noether-zh-hans/releases/tag/v1.0.0)的正文；其德文底本为ED0011/v047（2026-08-08）。其中第1篇至第19篇第6节的早期中文文本见2026-06-12法文与简体中文汇编。后续历史记录包括[v1.0.2](https://github.com/KokunoYumeto/emmy-noether-zh-hans/releases/tag/v1.0.2)及[v1.0.3](https://github.com/KokunoYumeto/emmy-noether-zh-hans/releases/tag/v1.0.3)。简体中文版的全部发布见[GitHub发布列表](https://github.com/KokunoYumeto/emmy-noether-zh-hans/releases)。

埃米·诺特于1935年去世，因此她的著作在欧盟以及保护期于作者去世后70年届满的所有地方均属公有领域。在美国，她于1931年或以后首次发表的论文自发表起95年内仍受保护（1931年的论文于2027年1月1日起不再受保护）。在发行者对AI完成的翻译、校正与排版享有权利的范围内，这些权利依[CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/deed.zh-hans)献入公有领域。M. Deuring记录的讲义、H. Kapferer的论文以及所列合著者的贡献不在本声明范围内；其权利仍归其作者或继承人。

[早期权利声明](NOTICE_HISTORIQUE.md)按原文保留，其效力限于实际授权的权利与贡献。

所附Noto字体适用SIL Open Font License 1.1。各字体文件内的版权、设计者、商标与许可信息见[字体署名](source/fonts/ATTRIBUTION.md)，[所附许可证原文](source/fonts/OFL.txt)亦予保留。TeX软件和未随包分发的系统字体适用其各自条件。

## 字形转换方法、代码与分项署名

R9中文汇编及繁体字转换程序：OpenAI Codex——GPT-5.6 Sol，Ultra推理强度，2026-08-12。

繁体字形式由简体文本经opencc-python-reimplemented 0.1.7的s2t配置和固定正字规则生成；两种字形属于同一个中文译本。

本版AI订正与排版：OpenAI Codex——GPT-6 Astra，Ultra推理强度，2026-10-23至2026-10-24；Claude Opus 5.5（Anthropic，max推理强度），2026-10-26至2026-10-27（公式已与依Noether印刷页面读出的德文本文核对）。

最初逐段翻译主要由GPT-5.6 Sol（OpenAI Codex，推理强度ultra）完成，具体工作日期尚未确定；2026-06-12是早期汇编的版本日期。


[字形转换方法、代码与分项署名](https://github.com/KokunoYumeto/emmy-noether-zh-hans/blob/main/methods/chinese-script-2026-10-24-r2/README.md)
