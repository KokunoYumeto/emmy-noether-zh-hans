# 早期简体中文版的权利声明

以下按原文保留。其范围限于声明者实际拥有并已授权的贡献，不构成当前整部版本的新许可。

```text
Mixed open licensing

Project-created material — CC0 1.0 Universal

埃米·诺特于1935年去世，因此她的著作在欧盟以及保护期于作者去世后70年届满的所有地方均属公有领域。在美国，她于1931年或以后首次发表的论文自发表起95年内仍受保护（1931年的论文于2027年1月1日起不再受保护）。在发行者对AI完成的翻译、校正与排版享有权利的范围内，这些权利依[CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/deed.zh-hans)献入公有领域。M. Deuring记录的讲义、H. Kapferer的论文以及所列合著者的贡献不在本声明范围内；其权利仍归其作者或继承人。

https://creativecommons.org/publicdomain/zero/1.0/

The original Emmy Noether works are public-domain historical works.

Bundled Noto font files remain under the SIL Open Font License 1.1; the complete
OFL text is included beside those fonts. Third-party source material and evidence
retain their own rights and attribution. Inclusion in this research package does
not relicense those materials. The Zenodo record therefore uses “Other (Open)”
for the mixed-rights deposit; this file controls the component-level terms.
```
